# 当前验证记录

日期：2026-10-29。环境：Linux，OpenJDK 21.0.12.1，Python 3.12。

执行 `python tools/test_core.py`：**32 项规则／识别／UCI 检查 + 15 项控制流程检查，共 47 项通过**。核心 Java 源码编译通过，使用 Java 8 语言及字节码目标。当前运行环境没有历史 JDK API 符号表，因此采用 `-source 8 -target 8`；这不能替代 Android SDK 的 API 检查。

已验证内容：

- 初始局面 FEN 往返，合法着法一层 44、两层 1920。
- 马腿、炮架、车不能跳子、将帅照面、自陷被将与局面变化校验。
- 原始三张用户样图全部 90 个交叉点正确识别，没有不确定格。
- 第二张仍为初始局面，检测到右红炮抬高；第三张识别红马 h0g2、黑炮 h7e7 后的局面和选中棋子。
- 0.65 倍与 1.5 倍缩放识别；翻转棋盘坐标映射。
- UCI 协议握手、走法解析与合法性检查、等待时取消。使用协议测试进程，不是实际皮卡鱼。
- 自动点击源格与目标格顺序、选子抬高核对、落子回读、对手快速回棋、走棋历史。
- 未选中时不点击落点；落子失败不重试、不虚构局面更新；停止前后取消后续点击。
- 提示模式不点击；无障碍不可用时回退至提示。
- Manifest 和资源 XML 可解析；构建工具 Python 文件通过语法编译。
- 12 个 Android 应用 Java 源文件通过编译器语法解析；此项未进行 Android SDK 类型与 API 检查。

完整 APK 构建尝试止于工具链检查，实际输出：

```text
BUILD FAILED: Install Android Studio and Android SDK Platform 35,
then set ANDROID_HOME or open this project in Android Studio once.
```

当前没有 Android SDK、没有下载好的官方 Android 皮卡鱼、没有成功构建的 APK。未进行手机安装、MediaProjection、悬浮窗、无障碍、触摸坐标、后台生命周期、NNUE 或实际自动对局验证。需要在具备 SDK 和网络的构建环境中生成 APK 后逐项实机验证。
