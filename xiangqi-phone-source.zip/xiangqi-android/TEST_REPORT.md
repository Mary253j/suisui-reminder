# 当前验证记录

日期：2026-10-29。环境：Linux，OpenJDK 21.0.12.1，Python 3.12。

执行 `python tools/test_core.py`：**32 项规则／识别／UCI 检查 + 15 项控制流程检查，共 47 项通过**。核心 Java 源码编译通过，使用 Java 8 语言及字节码目标。当前运行环境没有历史 JDK API 符号表，因此采用 `-source 8 -target 8`；这不能替代 Android SDK 的 API 检查。

已验证内容：

- 初始局面 FEN 往返，合法着法一层 44、两层 1920。
- 马腿、炮架、车不能跳子、将帅照面、自陷被将与局面变化校验。
- 原始三张用户样图全部 90 个交叉点正确识别，没有不确定格。
- 第二张仍为初始局面，检测到右红炮抬高；第三张识别红马 h0g2、黑炮 h7e7 后的局面和选中棋子。
- 0.65 倍与 1.5 倍缩放识别；翻转棋盘坐标映射。
- UCI 协议握手、走法解析与合法性检查、等待时取消。使用协议测试进程，不是实际皮卡鱼。
- 自动点击源格与目标格顺序、选子抬高核对、落子回读、对手快速回棋、走棋历史。
- 未选中时不点击落点；落子失败不重试、不虚构局面更新；停止前后取消后续点击。
- 提示模式不点击；无障碍不可用时回退至提示。
- Manifest 和资源 XML 可解析；构建工具 Python 文件通过语法编译。
- 12 个 Android 应用 Java 源文件通过编译器语法解析；此项未进行 Android SDK 类型与 API 检查。

## 云端 APK 构建

2026-10-29，通过用户授权的独立分支，在 GitHub Actions Ubuntu 24.04、JDK 21、Android SDK 35 环境构建成功。首次完整通过的记录：
https://github.com/Mary253j/suisui-reminder/actions/runs/40808869305

- 云端不上传原始截图，执行 `python tools/test_core.py --no-images`，18 项核心检查与 15 项控制检查通过。
- Android Gradle Plugin 8.7.3、Gradle 8.9 完成 Android 源码编译、DEX、资源及 APK 打包。
- `apksigner verify --verbose` 签名验证通过；`aapt dump badging` 可正确解析应用和图标。
- 安装包包含 ARM64 官方皮卡鱼、匹配 NNUE、识别模板、GPL 许可证和对应引擎源码。
- 官方发布包 SHA-256 验证通过；选择 `Pikafish-Android-arm64-universal` 静态 ARM64 可执行文件。
- 该官方引擎的 16 KB 页对齐检查为 False，当前交付目标为兼容 4 KB 页的 ARM64 手机。

截屏代码保留悬浮窗隐藏后收到的新帧，等待画面稳定后交给识别器；避免静止棋盘只更新一次时等待后续帧超时。此项通过 SDK 编译检查，仍需真机覆盖截屏时序。

尚未进行手机安装、MediaProjection、悬浮窗、无障碍、触摸坐标、后台生命周期、官方 ARM64 引擎启动、NNUE 加载或实际自动对局验证。协议测试进程不能替代真实皮卡鱼运行验证。
