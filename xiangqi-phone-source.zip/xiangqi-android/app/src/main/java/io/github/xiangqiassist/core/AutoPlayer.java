package io.github.xiangqiassist.core;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Screen-independent control loop, shared by the Android adapter and JVM tests. */
public final class AutoPlayer {
    public interface Environment {
        Recognizer.Observation read() throws Exception;
        boolean inputAvailable();
        void tap(int square) throws Exception;
        void hint(Position.Move move);
        void status(String text);
        void position(Position position);
    }
    public interface Brain extends AutoCloseable { Position.Move bestMove(Session session) throws Exception; }
    public interface Factory { Brain open() throws Exception; }
    private final Environment env; private final AtomicBoolean cancel; private final long pause,verifyTimeout;
    public AutoPlayer(Environment env,AtomicBoolean cancel) { this(env,cancel,150,12000); }
    public AutoPlayer(Environment env,AtomicBoolean cancel,long pause,long verifyTimeout) {
        this.env=env; this.cancel=cancel; this.pause=pause; this.verifyTimeout=verifyTimeout;
    }
    private void check() throws InterruptedException { if (cancel.get()||Thread.currentThread().isInterrupted()) throw new InterruptedException("已暂停"); }
    private void sleep(long ms) throws InterruptedException {
        long end=System.nanoTime()+ms*1000000;
        while (System.nanoTime()<end) { check(); Thread.sleep(Math.min(25,Math.max(1,(end-System.nanoTime())/1000000))); }
        check();
    }
    public Recognizer.Observation stable(long timeout,boolean allowLifted) throws Exception {
        long end=System.nanoTime()+timeout*1000000; Recognizer.Observation previous=null,last=null;
        while (System.nanoTime()<end) {
            check(); last=env.read(); check();
            if (last.stableCandidate(allowLifted)) {
                if (previous!=null&&last.board.equals(previous.board)&&last.lifted.equals(previous.lifted)) return last;
                previous=last;
            } else { previous=null; env.hint(null); }
            sleep(pause);
        }
        throw new IllegalStateException("棋盘未稳定："+(last!=null&&!last.issues.isEmpty()?String.join("；",last.issues):"请取消选子、关闭遮挡或重新校准"));
    }
    private static final class InputFailure extends Exception { InputFailure(String s) { super(s); } }
    private void tap(int index) throws Exception {
        check();
        if (!env.inputAvailable()) throw new InputFailure("自动点击不可用或已离开目标应用");
        try { env.tap(index); } catch (InterruptedException e) { throw e; }
        catch (Exception e) { throw new InputFailure(e.getMessage()); }
    }
    public boolean execute(Session session,Position.Move move) throws Exception {
        if (!session.position().legal(move)) throw new IllegalStateException("计划走法非法");
        Recognizer.Observation fresh=stable(10000,false);
        if (!fresh.board.equals(session.position().board)) throw new IllegalStateException("计算期间棋盘已变化，请重新预览");
        try {
            env.hint(null); tap(move.from); sleep(200);
            Recognizer.Observation selected=env.read(); check();
            if (!selected.issues.isEmpty()||!selected.board.equals(session.position().board)||!selected.lifted.equals(Collections.singleton(move.from)))
                throw new InputFailure("第一次点击后未确认预期棋子抬高");
            tap(move.to);
            long end=System.nanoTime()+verifyTimeout*1000000; String previous="";
            while (System.nanoTime()<end) {
                check(); Recognizer.Observation o=env.read(); check();
                if (o.stableCandidate(false)) {
                    if (o.board.equals(previous)&&session.verifyMove(move,o.board)) { env.position(session.position()); return true; }
                    previous=o.board;
                } else previous="";
                sleep(pause);
            }
            throw new InputFailure("落子没有通过核对，不再重复点击");
        } catch (InputFailure e) {
            env.hint(move);
            env.status("自动操作已暂停，保留本步参考提示："+e.getMessage()+"。请核对实际局面，必要时取消选子，再点预览。");
            return false;
        }
    }
    public void run(String approved,char initialSide,char ourSide,boolean automatic,Factory factory) throws Exception {
        Recognizer.Observation fresh=stable(12000,false);
        if (!fresh.board.equals(approved)) throw new IllegalStateException("局面与确认预览不同，请重新预览");
        Session session=new Session(new Position(approved,initialSide)); env.position(session.position());
        if (automatic&&!env.inputAvailable()) { automatic=false; env.status("自动点击未就绪，已切换悬浮提示模式"); }
        try (Brain engine=factory.open()) {
            Position.Move suggestion=null;
            while (true) {
                check();
                if (session.position().side==ourSide && suggestion==null) {
                    if (session.position().legalMoves().isEmpty()) { env.status("当前方已无合法走法"); env.hint(null); return; }
                    env.status("皮卡鱼思考中…");
                    suggestion=engine.bestMove(session); check();
                    if (suggestion==null||!session.position().legal(suggestion)) throw new IllegalStateException("引擎没有返回合法走法");
                    if (automatic) {
                        if (!execute(session,suggestion)) return;
                        suggestion=null; continue;
                    }
                    env.hint(suggestion); env.status("提示 "+Position.name(session.position().board.charAt(suggestion.from))+" "+suggestion+"；跟随箭头落子");
                }
                if (session.position().side!=ourSide) env.status("等待对方走棋…");
                Recognizer.Observation o=stable(12000,false);
                if (!o.board.equals(session.position().board)) {
                    Position.Move observed=session.position().transition(o.board);
                    if (observed!=null) session.observe(o.board);
                    else if (suggestion==null||!session.verifyMove(suggestion,o.board)) throw new IllegalStateException("检测到无法解释的局面变化，请重新预览");
                    suggestion=null; env.hint(null); env.position(session.position());
                } else if (!automatic&&suggestion!=null) env.hint(suggestion);
                sleep(pause);
            }
        }
    }
}
