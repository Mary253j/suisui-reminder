package io.github.xiangqiassist;

import android.app.*;
import android.content.*;
import android.media.projection.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public final class MainActivity extends Activity {
    private static final int CAPTURE=120;
    private Config config; private Spinner mode,side,turn,direction;
    private EditText think; private TextView status;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); config=new Config(this);
        ScrollView scroll=new ScrollView(this); scroll.setFitsSystemWindows(true); LinearLayout body=new LinearLayout(this); body.setOrientation(1);
        int p=dp(24); body.setPadding(p,p,p,p); scroll.addView(body); setContentView(scroll);
        TextView title=text("皮卡鱼 · 手机助手",25); title.setTextColor(0xff075f55); body.addView(title);
        body.addView(text("直接识别手机棋盘，用悬浮窗提示走法。开启无障碍后可尝试自动选子、落点。",16));
        status=text("",14); body.addView(status);
        button(body,"1. 允许悬浮窗",()->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
        button(body,"2. 开启自动点击（可选）",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        if (Build.VERSION.SDK_INT>=33) button(body,"允许状态通知（可选）",()->requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},121));
        mode=choice(body,"走棋方式",new String[]{"只显示提示","优先自动，失败时提示"},config.auto()?1:0);
        side=choice(body,"我执棋",new String[]{"红方","黑方"},config.ours()=='w'?0:1);
        turn=choice(body,"当前轮到",new String[]{"红方","黑方"},config.turn()=='w'?0:1);
        direction=choice(body,"棋盘方向",new String[]{"红方在下","红方在上"},config.redBottom()?0:1);
        body.addView(text("每步思考时间（毫秒，100–10000）",14));
        think=new EditText(this); think.setInputType(2); think.setText(String.valueOf(config.think())); body.addView(think);
        button(body,"3. 开启屏幕识别与悬浮窗",this::startCapture);
        button(body,"结束手机助手",()->{ stopService(new Intent(this,CaptureService.class)); refresh(); });
        body.addView(text("开启后切回象棋，拖动悬浮窗到棋盘外：校准 → 核对自动找到的方框 → 确认 → 预览 → 开始。方框可拖动，角点可用箭头微调。",16));
        body.addView(text("屏幕捕获和无障碍授权由 Android 系统控制。只在本机处理截图，不上传；停止服务后结束捕获。中途接局需要自己设置行棋方。",14));
        body.addView(text("如果游戏禁止截图或隐藏悬浮窗，本应用会暂停。当前仅适配你提供的棋子皮肤。",14));
    }
    private int dp(int n) { return Math.round(n*getResources().getDisplayMetrics().density); }
    private TextView text(String s,int size) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(0,dp(8),0,dp(8)); return t; }
    private void button(LinearLayout body,String label,Runnable action) {
        Button b=new Button(this); b.setText(label); b.setOnClickListener(v->action.run()); body.addView(b);
    }
    private Spinner choice(LinearLayout body,String label,String[] values,int selected) {
        body.addView(text(label,14)); Spinner s=new Spinner(this);
        ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,values);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); s.setAdapter(a); s.setSelection(selected); body.addView(s); return s;
    }
    @Override protected void onResume() { super.onResume(); refresh(); }
    private void refresh() {
        if (status!=null) status.setText("悬浮窗："+(Settings.canDrawOverlays(this)?"已开启":"未开启")+"　自动点击："
                +(ChessAccessibilityService.connected()?"已连接":"未连接（可只提示）")+"\n屏幕服务："+(CaptureService.running?"运行中":"未启动"));
    }
    private void startCapture() {
        if (CaptureService.running) { new AlertDialog.Builder(this).setMessage("服务正在运行。要改设置，请先结束服务，再重新开启。").setPositiveButton("知道了",null).show(); return; }
        if (!Settings.canDrawOverlays(this)) { Toast.makeText(this,"请先允许悬浮窗",Toast.LENGTH_LONG).show(); return; }
        try {
            int ms=Integer.parseInt(think.getText().toString());
            if (ms<100||ms>10000) throw new IllegalArgumentException();
            config.save(mode.getSelectedItemPosition()==1,direction.getSelectedItemPosition()==0,side.getSelectedItemPosition()==0,turn.getSelectedItemPosition()==0,ms);
        } catch (IllegalArgumentException e) { Toast.makeText(this,"思考时间填写 100–10000 毫秒",Toast.LENGTH_LONG).show(); return; }
        MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent capture=Build.VERSION.SDK_INT>=34?manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay()):manager.createScreenCaptureIntent();
        startActivityForResult(capture,CAPTURE);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if (request==CAPTURE && result==RESULT_OK && data!=null) {
            Intent service=new Intent(this,CaptureService.class).putExtra("result",result).putExtra("projection",data);
            startForegroundService(service);
            Toast.makeText(this,"请切回棋盘，在悬浮窗里校准和预览",Toast.LENGTH_LONG).show();
            moveTaskToBack(true);
        }
    }
}
