package io.github.xiangqiassist;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.Toast;
import io.github.xiangqiassist.core.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Foreground-only screen capture. No network permission is requested by the app. */
public final class CaptureService extends Service implements OverlayUi.Actions {
    public static volatile boolean running=false;
    private static final int NOTIFICATION=20;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AtomicLong generation=new AtomicLong();
    private volatile AtomicBoolean cancel=new AtomicBoolean();
    private volatile boolean destroyed=false;
    private MediaProjection projection; private VirtualDisplay display; private ImageReader reader;
    private HandlerThread imageThread; private Handler imageHandler;
    private OverlayUi ui; private Config config; private Recognizer recognizer;
    private int width,height;
    private volatile FrameRequest pending;
    private volatile long lastImageTimestamp=Long.MIN_VALUE;
    private String lastLog="";

    private static final class FrameRequest {
        volatile long notBefore=Long.MAX_VALUE;
        final long afterTimestamp;
        final CountDownLatch latch=new CountDownLatch(1);
        volatile Recognizer.Frame frame; volatile Exception error;
        FrameRequest(long afterTimestamp) { this.afterTimestamp=afterTimestamp; }
    }
    private interface Task { void run(long id,AtomicBoolean token) throws Exception; }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if (intent==null || "stop".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection!=null) return START_NOT_STICKY;
        try {
            config=new Config(this); startForegroundNotification();
            Intent consent=intent.getParcelableExtra("projection");
            int result=intent.getIntExtra("result",Activity.RESULT_CANCELED);
            if (consent==null||result!=Activity.RESULT_OK) throw new IllegalStateException("缺少系统屏幕捕获授权，请重新开启");
            MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=manager.getMediaProjection(result,consent);
            if (projection==null) throw new IllegalStateException("屏幕捕获授权无效");
            DisplayMetrics metrics=new DisplayMetrics(); ((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(metrics);
            width=metrics.widthPixels; height=metrics.heightPixels;
            projection.registerCallback(new MediaProjection.Callback(){
                @Override public void onStop() { stopSelf(); }
                @Override public void onCapturedContentResize(int w,int h) {
                    if (w!=width||h!=height) {
                        Toast.makeText(CaptureService.this,"屏幕尺寸变化，请重新开启助手并校准棋盘",Toast.LENGTH_LONG).show(); stopSelf();
                    }
                }
                @Override public void onCapturedContentVisibilityChanged(boolean visible) { if (!visible) pause(); }
            },main);
            imageThread=new HandlerThread("screen-frames"); imageThread.start(); imageHandler=new Handler(imageThread.getLooper());
            reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,3);
            reader.setOnImageAvailableListener(this::onImage,imageHandler);
            display=projection.createVirtualDisplay("xiangqi-screen",width,height,metrics.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,imageHandler);
            recognizer=new Recognizer(getAssets().open("templates.bin"));
            ui=new OverlayUi(this,this); running=true;
        } catch (Exception e) { Toast.makeText(this,"启动失败："+e.getMessage(),Toast.LENGTH_LONG).show(); log(e.toString()); stopSelf(); }
        return START_NOT_STICKY;
    }
    private void startForegroundNotification() {
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(new NotificationChannel("chess", "棋盘识别",NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop=PendingIntent.getService(this,2,new Intent(this,CaptureService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification=new Notification.Builder(this,"chess").setSmallIcon(R.drawable.ic_chess_notification)
                .setContentTitle("象棋手机助手正在读取屏幕").setContentText("可在悬浮窗暂停，或点击停止结束捕获").setContentIntent(open)
                .setOngoing(true).addAction(android.R.drawable.ic_menu_close_clear_cancel,"停止",stop).build();
        if (Build.VERSION.SDK_INT>=29) startForeground(NOTIFICATION,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(NOTIFICATION,notification);
    }
    private void onImage(ImageReader source) {
        Image image=null; FrameRequest request=pending;
        try {
            image=source.acquireLatestImage();
            if (image==null) return;
            long timestamp=image.getTimestamp(); lastImageTimestamp=timestamp;
            if (request==null||timestamp<=request.afterTimestamp||request.latch.getCount()==0) return;
            if (image.getWidth()!=width||image.getHeight()!=height) throw new IllegalStateException("截图尺寸变化");
            Image.Plane plane=image.getPlanes()[0]; ByteBuffer bytes=plane.getBuffer();
            int row=plane.getRowStride(),pixel=plane.getPixelStride(); int[] rgb=new int[width*height];
            for (int y=0;y<height;y++) for (int x=0;x<width;x++) {
                int offset=y*row+x*pixel;
                rgb[y*width+x]=((bytes.get(offset)&255)<<16)|((bytes.get(offset+1)&255)<<8)|(bytes.get(offset+2)&255);
            }
            // Keep the newest frame while the overlay settles. Static displays may
            // emit only the frame caused by hiding the overlay, with no later frame.
            request.frame=new Recognizer.Frame(width,height,rgb);
            if (SystemClock.uptimeMillis()>=request.notBefore) request.latch.countDown();
        } catch (Exception e) { if (request!=null) { request.error=e; request.latch.countDown(); } }
        finally { if (image!=null) image.close(); }
    }
    private void post(long id,Runnable action) { main.post(()->{ if (!destroyed&&id==generation.get()&&ui!=null) action.run(); }); }
    private void uiSync(long id,Runnable action) throws Exception {
        CountDownLatch latch=new CountDownLatch(1);
        main.post(()->{ try { if (!destroyed&&id==generation.get()&&ui!=null) action.run(); } finally { latch.countDown(); } });
        if (!latch.await(2,TimeUnit.SECONDS)) throw new IllegalStateException("界面未响应，请暂停重试");
    }
    private void check(long id,AtomicBoolean token) throws InterruptedException {
        if (destroyed||id!=generation.get()||token.get()||Thread.currentThread().isInterrupted()) throw new InterruptedException("已暂停");
    }
    private void delay(long id,AtomicBoolean token,int ms) throws InterruptedException {
        long end=SystemClock.uptimeMillis()+ms;
        while (SystemClock.uptimeMillis()<end) { check(id,token); Thread.sleep(20); }
        check(id,token);
    }
    private Recognizer.Frame frame(long id,AtomicBoolean token) throws Exception {
        check(id,token);
        FrameRequest request=new FrameRequest(lastImageTimestamp);
        Runnable settled=()->{
            if (pending==request&&request.frame!=null) request.latch.countDown();
        };
        try {
            // Install the request before hiding: even the first resulting screen
            // update must be retained when the chess app is otherwise static.
            uiSync(id,()->{ pending=request; ui.hidden(true); request.notBefore=SystemClock.uptimeMillis()+140; });
            check(id,token);
            imageHandler.postAtTime(settled,request.notBefore);
            long end=SystemClock.uptimeMillis()+4000;
            while (!request.latch.await(40,TimeUnit.MILLISECONDS)) {
                check(id,token);
                if (SystemClock.uptimeMillis()>end) throw new IllegalStateException("没有收到新画面。游戏可能限制截屏，或屏幕捕获已停止");
            }
            check(id,token);
            if (request.error!=null) throw request.error;
            if (request.frame==null) throw new IllegalStateException("截图不可用");
            return request.frame;
        } finally {
            if (pending==request) pending=null;
            imageHandler.removeCallbacks(settled);
            post(id,()->ui.hidden(false));
        }
    }
    private AutoPlayer.Environment environment(long id,AtomicBoolean token,Grid grid) {
        return new AutoPlayer.Environment(){
            @Override public Recognizer.Observation read() throws Exception { return recognizer.read(frame(id,token),grid,token); }
            @Override public boolean inputAvailable() {
                return ChessAccessibilityService.connected()&&!config.target().isEmpty()&&config.target().equals(ChessAccessibilityService.foreground());
            }
            @Override public void tap(int square) throws Exception {
                check(id,token); uiSync(id,()->ui.hidden(true));
                try { delay(id,token,150); ChessAccessibilityService.tap(grid.x(square),grid.y(square),config.target(),token); }
                finally { post(id,()->ui.hidden(false)); }
            }
            @Override public void hint(Position.Move move) { post(id,()->ui.hint(grid,move)); }
            @Override public void status(String text) { log(text); post(id,()->ui.status(text)); }
            @Override public void position(Position position) {
                if (id!=generation.get()||token.get()) return;
                config.prefs.edit().putBoolean("turnRed",position.side=='w').apply();
                log("局面 "+position.fen());
            }
        };
    }
    private void task(Task action) {
        cancel.set(true); AtomicBoolean token=new AtomicBoolean(); cancel=token; long id=generation.incrementAndGet();
        if (ui!=null) { ui.closeModal(); ui.hint(null,null); ui.hidden(false); }
        worker.execute(()->{
            try { check(id,token); action.run(id,token); }
            catch (InterruptedException e) { post(id,()->ui.status("已暂停；若有棋子抬高，请先取消选择")); }
            catch (Exception e) {
                log("异常："+e); post(id,()->{ ui.hint(null,null); ui.status("已暂停："+e.getMessage()); });
            } finally { post(id,()->ui.hidden(false)); }
        });
    }
    @Override public void calibrate() {
        task((id,token)->{
            post(id,()->ui.status("正在自动定位棋盘…"));
            Recognizer.Frame screenshot=frame(id,token);
            Grid located;boolean automatic=true;
            try {located=recognizer.alignGrid(screenshot,BoardLocator.find(screenshot,config.redBottom(),token),token);}
            catch(IllegalArgumentException e) {
                automatic=false;
                located=new Grid(width*.07,height*.285,width*.93,height*.714,config.redBottom());
            }
            check(id,token);
            String foreground=ChessAccessibilityService.foreground();
            final String target=(!ChessAccessibilityService.connected()||foreground.equals(getPackageName())||foreground.equals("com.android.systemui")||foreground.equals("android"))?"":foreground;
            final Grid grid=located;final boolean found=automatic;
            post(id,()->ui.calibrate(screenshot,grid,found,(x0,y0,x8,y9)->{
                try {
                    config.calibrate(new Grid(x0,y0,x8,y9,config.redBottom()),width,height,target);
                    ui.status("校准完成，点预览核对棋子"+(target.isEmpty()?"；自动点击尚未绑定目标应用":""));
                } catch(Exception e) {ui.status("校准失败："+e.getMessage());}
            }));
        });
    }
    @Override public void preview() {
        task((id,token)->{
            Grid grid=config.grid(width,height); AutoPlayer.Environment env=environment(id,token,grid);
            env.status("识别预览中…");
            Recognizer.Observation obs=new AutoPlayer(env,token).stable(12000,false);
            Position position=new Position(obs.board,config.turn());
            if (!position.problems().isEmpty()) throw new IllegalStateException(String.join("；",position.problems()));
            post(id,()->{ ui.status("请核对棋盘，确认后开始"); ui.preview(position,grid.redBottom,()->startGame(obs.board,position.side)); });
        });
    }
    private void startGame(String board,char initialSide) {
        task((id,token)->{
            Grid grid=config.grid(width,height); AutoPlayer.Environment env=environment(id,token,grid);
            AutoPlayer player=new AutoPlayer(env,token);
            player.run(board,initialSide,config.ours(),config.auto(),()->{
                env.status("准备皮卡鱼引擎…"); UciEngine engine=EngineFiles.open(this,token);
                if (!engine.name.toLowerCase(java.util.Locale.ROOT).contains("pikafish")) { engine.close(); throw new IOException("引擎身份不是 Pikafish"); }
                return new AutoPlayer.Brain(){
                    @Override public Position.Move bestMove(Session session) throws Exception { return engine.bestMove(session,config.think()); }
                    @Override public void close() { engine.close(); }
                };
            });
        });
    }
    @Override public void pause() {
        cancel.set(true); generation.incrementAndGet();
        if (ui!=null) { ui.closeModal(); ui.hint(null,null); ui.hidden(false); ui.status("已暂停；若有棋子抬高，请先取消选择。继续前重新预览。"); }
    }
    @Override public void close() { stopSelf(); }
    private synchronized void log(String text) {
        if (text.equals(lastLog)) return; lastLog=text;
        try (Writer writer=new FileWriter(new File(getFilesDir(),"session.log"),true)) { writer.write(System.currentTimeMillis()+" "+text+"\n"); }
        catch (IOException ignored) {}
    }
    @Override public void onDestroy() {
        destroyed=true; running=false; cancel.set(true); generation.incrementAndGet(); worker.shutdownNow();
        FrameRequest request=pending;
        if (request!=null) { request.error=new IOException("屏幕服务已停止"); request.latch.countDown(); }
        if (display!=null) display.release();
        if (reader!=null) reader.close();
        if (projection!=null) projection.stop();
        if (imageThread!=null) imageThread.quitSafely();
        if (ui!=null) { try { ui.destroy(); } catch (IllegalArgumentException ignored) {} }
        stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy();
    }
}
