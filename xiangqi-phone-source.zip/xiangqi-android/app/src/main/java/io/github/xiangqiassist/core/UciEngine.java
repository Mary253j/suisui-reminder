package io.github.xiangqiassist.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class UciEngine implements AutoCloseable {
    private final Process process; private final BufferedWriter input;
    private final BlockingQueue<String> lines=new LinkedBlockingQueue<>();
    private final AtomicBoolean cancelled; private final Set<String> options=new HashSet<>();
    private static final String EOF="\u0000EOF";
    public String name="Pikafish";
    public UciEngine(List<String> command,File directory,String network,AtomicBoolean cancelled) throws Exception {
        this.cancelled=cancelled;
        process=new ProcessBuilder(command).directory(directory).redirectErrorStream(true).start();
        input=new BufferedWriter(new OutputStreamWriter(process.getOutputStream(),StandardCharsets.UTF_8));
        Thread reader=new Thread(()->{
            try (BufferedReader r=new BufferedReader(new InputStreamReader(process.getInputStream(),StandardCharsets.UTF_8))) {
                String line; while ((line=r.readLine())!=null) lines.offer(line);
            } catch (IOException ignored) {} finally { lines.offer(EOF); }
        },"pikafish-reader"); reader.setDaemon(true); reader.start();
        try {
            send("uci"); until("uciok",15000);
            if (options.contains("Threads")) send("setoption name Threads value 2");
            if (options.contains("Hash")) send("setoption name Hash value 64");
            if (network!=null&&!network.isEmpty()&&options.contains("EvalFile")) send("setoption name EvalFile value "+network);
            send("ucinewgame"); send("isready"); until("readyok",30000);
        } catch (Exception e) { close(); throw e; }
    }
    private synchronized void send(String command) throws IOException {
        if (command.contains("\n")||command.contains("\r")) throw new IOException("UCI 命令包含换行");
        input.write(command); input.newLine(); input.flush();
    }
    private String until(String prefix,long timeout) throws Exception {
        long end=System.nanoTime()+timeout*1000000L; String last="";
        while (System.nanoTime()<end) {
            if (cancelled.get()||Thread.currentThread().isInterrupted()) throw new InterruptedException("已暂停");
            String s=lines.poll(50,TimeUnit.MILLISECONDS);
            if (s==null) continue;
            if (s.equals(EOF)) throw new IOException("皮卡鱼退出："+last);
            last=s;
            if (s.contains("CRITICAL ERROR")||s.contains("ERROR:")) throw new IOException(s);
            if (s.startsWith("id name ")) name=s.substring(8);
            if (s.startsWith("option name ")) options.add(s.substring(12).split(" type ")[0]);
            if (s.startsWith(prefix)) return s;
        }
        throw new IOException("等待皮卡鱼 "+prefix+" 超时："+last);
    }
    public Position.Move bestMove(Session session,int millis) throws Exception {
        List<String> history=session.history();
        send("position fen "+session.initialFen+(history.isEmpty()?"":" moves "+String.join(" ",history)));
        send("go movetime "+millis);
        String s=until("bestmove ",millis+15000).split(" ")[1];
        if (s.equals("0000")||s.equals("(none)")) return null;
        Position.Move move=Position.Move.parse(s);
        if (!session.position().legal(move)) throw new IOException("引擎走法未通过合法性检查");
        return move;
    }
    @Override public void close() {
        try { send("stop"); send("quit"); } catch (IOException ignored) {}
        try { if (!process.waitFor(800,TimeUnit.MILLISECONDS)) process.destroyForcibly(); }
        catch (InterruptedException e) { process.destroyForcibly(); Thread.currentThread().interrupt(); }
        try { input.close(); } catch (IOException ignored) {}
    }
}
