package io.github.xiangqiassist.core;

import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class Recognizer {
    public static final class Frame {
        public final int width,height; public final int[] pixels;
        public Frame(int width,int height,int[] pixels) {
            if (pixels.length!=width*height) throw new IllegalArgumentException("像素数量错误");
            this.width=width; this.height=height; this.pixels=pixels;
        }
        private int at(int x,int y) { return pixels[Math.max(0,Math.min(height-1,y))*width+Math.max(0,Math.min(width-1,x))]; }
        public int sample(double x,double y) {
            int ix=(int)Math.floor(x), iy=(int)Math.floor(y);
            double fx=x-ix, fy=y-iy; int a=at(ix,iy),b=at(ix+1,iy),c=at(ix,iy+1),d=at(ix+1,iy+1),rgb=0;
            for (int shift=0;shift<=16;shift+=8) {
                double top=((a>>shift)&255)*(1-fx)+((b>>shift)&255)*fx;
                double bottom=((c>>shift)&255)*(1-fx)+((d>>shift)&255)*fx;
                rgb|=((int)Math.round(top*(1-fy)+bottom*fy))<<shift;
            }
            return rgb;
        }
    }
    public static final class Observation {
        public final String board; public final float[] scores; public final List<String> issues; public final Set<Integer> lifted;
        public Observation(String board,float[] scores,List<String> issues,Set<Integer> lifted) {
            this.board=board; this.scores=scores; this.issues=issues; this.lifted=lifted;
        }
        public boolean stableCandidate(boolean allowLifted) { return issues.isEmpty()&&(allowLifted||lifted.isEmpty()); }
    }
    private final char[] labels; private final float[][] templates; private final float[] norms;
    private static final String CLASSES="KABNRCPkabnrcp";
    private static final double[] SHIFTS={0,-.08,.08,-.16,-.24,-.32}, SCALES={1,.93,1.07};
    public Recognizer(InputStream input) throws IOException {
        try (DataInputStream in=new DataInputStream(new BufferedInputStream(input))) {
            if (in.readInt()!=0x58515450) throw new IOException("模板格式错误");
            int count=in.readInt();
            if (count<14||count>64) throw new IOException("模板数量错误");
            labels=new char[count]; templates=new float[count][1024]; norms=new float[count];
            for (int t=0;t<count;t++) {
                labels[t]=(char)in.readUnsignedByte();
                if (CLASSES.indexOf(labels[t])<0) throw new IOException("模板标签错误");
                for (int j=0;j<1024;j++) { float v=in.readFloat(); templates[t][j]=v; norms[t]+=v*v; }
            }
        }
    }
    private static float clip(double x) { return (float)Math.max(0,Math.min(1,x)); }
    private static void glyph(Frame frame,Grid grid,int index,double shift,double scale,float[][] out) {
        double cx=grid.x(index),cy=grid.y(index)+(shift-.075)*grid.dy(),rx=.315*grid.dx()*scale,ry=.315*grid.dy()*scale;
        for (int y=0;y<32;y++) for (int x=0;x<32;x++) {
            int j=y*32+x; out[0][j]=out[1][j]=0;
            if ((x-15.5)*(x-15.5)+(y-15.5)*(y-15.5)>=15.5*15.5) continue;
            int rgb=frame.sample(cx-rx+(x+.5)*2*rx/32-.5,cy-ry+(y+.5)*2*ry/32-.5);
            int r=(rgb>>16)&255,g=(rgb>>8)&255,b=rgb&255;
            if (g>r*1.12&&g>b*1.12) continue;
            out[0][j]=clip((r-g-27)/40.)*clip((160-g)/50.);
            out[1][j]=clip((125-Math.max(r,g))/50.);
        }
    }
    public Observation read(Frame frame,Grid grid,AtomicBoolean cancelled) throws InterruptedException {
        grid.validate(frame.width,frame.height);
        StringBuilder board=new StringBuilder(); float[] scores=new float[90];
        List<String> issues=new ArrayList<>(); Set<Integer> lifted=new HashSet<>();
        float[][] values=new float[2][1024];
        for (int index=0;index<90;index++) {
            if (cancelled.get()||Thread.currentThread().isInterrupted()) throw new InterruptedException("已暂停");
            float[] best=new float[14]; double[] offsets=new double[14];
            for (double scale:SCALES) for (double shift:SHIFTS) {
                glyph(frame,grid,index,shift,scale,values);
                float[] sums=new float[2];
                for (int j=0;j<1024;j++) { sums[0]+=values[0][j]*values[0][j]; sums[1]+=values[1][j]*values[1][j]; }
                for (int t=0;t<labels.length;t++) {
                    int channel=Character.isUpperCase(labels[t])?0:1,cl=CLASSES.indexOf(labels[t]); float dot=0;
                    for (int j=0;j<1024;j++) dot+=values[channel][j]*templates[t][j];
                    float score=2*dot/(sums[channel]+norms[t]+.000001f);
                    if (score>best[cl]) { best[cl]=score; offsets[cl]=shift; }
                }
            }
            int winner=0; for (int c=1;c<14;c++) if (best[c]>best[winner]) winner=c;
            float first=best[winner],second=0;
            for (int c=0;c<14;c++) if (c!=winner) second=Math.max(second,best[c]);
            if (first<.48) { board.append('.'); scores[index]=1-first; continue; }
            board.append(CLASSES.charAt(winner)); scores[index]=first;
            if (first<.64 || first-second<.065) issues.add(Position.square(index)+"识别不确定");
            if (offsets[winner]<=-.16) lifted.add(index);
        }
        return new Observation(board.toString(),scores,issues,lifted);
    }
}
