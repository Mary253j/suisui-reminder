package io.github.xiangqiassist;

import android.accessibilityservice.*;
import android.graphics.Path;
import android.os.*;
import android.view.accessibility.AccessibilityEvent;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ChessAccessibilityService extends AccessibilityService {
    private static volatile ChessAccessibilityService instance;
    private static volatile String foreground="";
    public static boolean connected() { return instance!=null; }
    public static String foreground() { return foreground; }
    @Override protected void onServiceConnected() { instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.getPackageName()!=null) {
            String p=e.getPackageName().toString();
            if (!p.equals(getPackageName()) || MainActivity.class.getName().contentEquals(e.getClassName()==null?"":e.getClassName())) foreground=p;
        }
    }
    @Override public void onInterrupt() { instance=null; }
    @Override public void onDestroy() { instance=null; foreground=""; super.onDestroy(); }
    public static void tap(double x,double y,String target,AtomicBoolean cancel) throws Exception {
        ChessAccessibilityService service=instance;
        if (service==null) throw new IllegalStateException("无障碍服务未连接");
        if (target.isEmpty() || !target.equals(foreground)) throw new IllegalStateException("当前前台不是校准时的象棋应用");
        if (cancel.get()) throw new InterruptedException("已暂停");
        CountDownLatch latch=new CountDownLatch(1); AtomicBoolean success=new AtomicBoolean();
        new Handler(Looper.getMainLooper()).post(()->{
            if (cancel.get()||instance!=service||!target.equals(foreground)) { latch.countDown(); return; }
            Path path=new Path(); path.moveTo((float)x,(float)y);
            GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,55)).build();
            boolean submitted=service.dispatchGesture(gesture,new GestureResultCallback(){
                @Override public void onCompleted(GestureDescription d) { success.set(true); latch.countDown(); }
                @Override public void onCancelled(GestureDescription d) { latch.countDown(); }
            },null);
            if (!submitted) latch.countDown();
        });
        long end=System.nanoTime()+2500000000L;
        while (!latch.await(30,TimeUnit.MILLISECONDS)) {
            if (cancel.get()) throw new InterruptedException("已暂停");
            if (System.nanoTime()>end) throw new IllegalStateException("系统没有确认点击");
        }
        if (cancel.get()) throw new InterruptedException("已暂停");
        if (!success.get()) throw new IllegalStateException("点击被系统取消，改用悬浮提示");
    }
}
