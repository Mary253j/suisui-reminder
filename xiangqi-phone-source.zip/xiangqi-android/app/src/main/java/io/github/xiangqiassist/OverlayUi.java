package io.github.xiangqiassist;

import android.content.Context;
import android.graphics.*;
import android.os.Build;
import android.view.*;
import android.widget.*;
import io.github.xiangqiassist.core.*;
import java.util.*;

final class OverlayUi {
    interface Actions { void calibrate(); void preview(); void pause(); void close(); }
    interface Calibrated { void done(double x0,double y0,double x8,double y9); }
    private final Context context; private final WindowManager wm;
    private final LinearLayout panel; private final TextView status; private final Arrow arrow;
    private final WindowManager.LayoutParams panelParams;
    private View modal;
    private Position.Move hint; private Grid grid;
    private boolean hidden=false;
    OverlayUi(Context context,Actions actions) {
        this.context=context; wm=(WindowManager)context.getSystemService(Context.WINDOW_SERVICE);
        arrow=new Arrow(); WindowManager.LayoutParams ap=params(-1,-1,true); ap.alpha=.65f; wm.addView(arrow,ap);
        panel=new LinearLayout(context); panel.setOrientation(1); panel.setPadding(dp(8),dp(6),dp(8),dp(6)); panel.setBackgroundColor(0xee163a36);
        TextView handle=label("棋局助手 · 拖动此处",14); panel.addView(handle);
        status=label("切回棋盘：校准 → 预览",12); status.setMaxWidth(dp(270)); panel.addView(status);
        LinearLayout row=new LinearLayout(context); panel.addView(row);
        addButton(row,"校准",actions::calibrate); addButton(row,"预览",actions::preview); addButton(row,"暂停",actions::pause); addButton(row,"退出",actions::close);
        panelParams=params(dp(290),-2,false); panelParams.x=dp(8); panelParams.y=dp(40); wm.addView(panel,panelParams);
        handle.setOnTouchListener(new View.OnTouchListener(){
            float sx,sy; int ox,oy;
            @Override public boolean onTouch(View v,android.view.MotionEvent e) {
                if (e.getAction()==MotionEvent.ACTION_DOWN) { sx=e.getRawX(); sy=e.getRawY(); ox=panelParams.x; oy=panelParams.y; return true; }
                if (e.getAction()==MotionEvent.ACTION_MOVE) { panelParams.x=Math.max(0,ox+Math.round(e.getRawX()-sx)); panelParams.y=Math.max(0,oy+Math.round(e.getRawY()-sy)); wm.updateViewLayout(panel,panelParams); return true; }
                return true;
            }
        });
    }
    private int dp(int x) { return Math.round(x*context.getResources().getDisplayMetrics().density); }
    private TextView label(String text,int size) { TextView t=new TextView(context); t.setText(text); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setPadding(dp(4),dp(3),dp(4),dp(3)); return t; }
    private void addButton(LinearLayout row,String name,Runnable action) {
        Button b=new Button(context); b.setText(name); b.setTextSize(11); b.setMinWidth(0); b.setMinimumWidth(0); b.setPadding(dp(5),0,dp(5),0);
        row.addView(b,new LinearLayout.LayoutParams(0,dp(40),1)); b.setOnClickListener(v->action.run());
    }
    private WindowManager.LayoutParams params(int width,int height,boolean passThrough) {
        int flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (passThrough) flags|=WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(width,height,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,flags,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.LEFT;
        if (Build.VERSION.SDK_INT>=28) p.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        return p;
    }
    void status(String text) { status.setText(text); }
    void hint(Grid grid,Position.Move move) { this.grid=grid; hint=move; arrow.invalidate(); }
    void hidden(boolean hidden) {
        this.hidden=hidden; panel.setVisibility(hidden?View.GONE:View.VISIBLE); arrow.setVisibility(hidden?View.GONE:View.VISIBLE);
        if (hidden) panelParams.flags|=WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else panelParams.flags&=~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.updateViewLayout(panel,panelParams);
    }
    void closeModal() { if (modal!=null) { wm.removeView(modal); modal=null; } }
    void calibrate(Calibrated complete) {
        closeModal(); hint=null; arrow.invalidate(); panel.setVisibility(View.GONE);
        modal=new View(context){
            int count=0; float x,y; final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                paint.setColor(0xcc163a36); c.drawRect(0,dp(45),getWidth(),dp(120),paint);
                paint.setColor(Color.WHITE); paint.setTextSize(dp(17));
                c.drawText(count==0?"点左上角棋盘交叉点":"点右下角棋盘交叉点",dp(12),dp(76),paint);
                paint.setTextSize(dp(13)); c.drawText("点击最上方文字区可取消",dp(12),dp(102),paint);
                if (count>0) { int[] loc=new int[2]; getLocationOnScreen(loc); paint.setColor(Color.CYAN); c.drawCircle(x-loc[0],y-loc[1],dp(8),paint); }
            }
            @Override public boolean onTouchEvent(MotionEvent e) {
                if (e.getAction()!=MotionEvent.ACTION_UP) return true;
                if (e.getY()<dp(120)) { closeModal(); panel.setVisibility(View.VISIBLE); return true; }
                if (count++==0) { x=e.getRawX(); y=e.getRawY(); invalidate(); }
                else { float x2=e.getRawX(),y2=e.getRawY(); closeModal(); panel.setVisibility(View.VISIBLE); complete.done(x,y,x2,y2); }
                return true;
            }
        };
        wm.addView(modal,params(-1,-1,false));
    }
    void preview(Position position,boolean redBottom,Runnable confirm) {
        closeModal(); LinearLayout box=new LinearLayout(context); box.setOrientation(1); box.setPadding(dp(12),dp(8),dp(12),dp(8)); box.setBackgroundColor(0xff163a36);
        box.addView(label("核对每个棋子 · "+(position.side=='w'?"红":"黑")+"方行棋",16));
        View boardView=new View(context) {
            final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas canvas) {
                float step=Math.min((getWidth()-dp(24))/8f,(getHeight()-dp(24))/9f),x0=(getWidth()-8*step)/2,y0=(getHeight()-9*step)/2;
                paint.setColor(0xffd1b17b); paint.setStrokeWidth(dp(1));
                for (int r=0;r<10;r++) canvas.drawLine(x0,y0+r*step,x0+8*step,y0+r*step,paint);
                for (int c=0;c<9;c++) canvas.drawLine(x0+c*step,y0,x0+c*step,y0+9*step,paint);
                for (int i=0;i<90;i++) {
                    char piece=position.board.charAt(i); if (piece=='.') continue;
                    int r=redBottom?i/9:9-i/9,c=redBottom?i%9:8-i%9; float x=x0+c*step,y=y0+r*step;
                    paint.setColor(0xffffe6ad); canvas.drawCircle(x,y,step*.43f,paint);
                    paint.setColor(Character.isUpperCase(piece)?0xffb72121:0xff222222); paint.setTextSize(step*.65f); paint.setTextAlign(Paint.Align.CENTER);
                    canvas.drawText(Position.name(piece),x,y-(paint.ascent()+paint.descent())/2,paint);
                }
                paint.setTextAlign(Paint.Align.LEFT);
            }
        };
        android.util.DisplayMetrics dm=new android.util.DisplayMetrics(); wm.getDefaultDisplay().getRealMetrics(dm);
        int height=Math.min(dp(420),dm.heightPixels-dp(240));
        box.addView(boardView,new LinearLayout.LayoutParams(-1,Math.max(dp(220),height)));
        LinearLayout buttons=new LinearLayout(context); box.addView(buttons);
        addButton(buttons,"核对无误，开始",()->{ closeModal(); confirm.run(); });
        addButton(buttons,"返回",this::closeModal);
        modal=box; WindowManager.LayoutParams p=params(Math.min(dm.widthPixels-dp(24),dp(380)),-2,false); p.x=dp(12); p.y=dp(80); wm.addView(modal,p);
    }
    void destroy() { closeModal(); wm.removeView(panel); wm.removeView(arrow); }
    private final class Arrow extends View {
        final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        Arrow() { super(OverlayUi.this.context); }
        @Override protected void onDraw(Canvas c) {
            if (hint==null||grid==null||hidden) return;
            int[] loc=new int[2]; getLocationOnScreen(loc);
            float x=(float)grid.x(hint.from)-loc[0],y=(float)grid.y(hint.from)-loc[1],tx=(float)grid.x(hint.to)-loc[0],ty=(float)grid.y(hint.to)-loc[1];
            paint.setColor(Color.CYAN); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(4));
            c.drawCircle(x,y,dp(15),paint); c.drawCircle(tx,ty,dp(13),paint); c.drawLine(x,y,tx,ty,paint);
            double angle=Math.atan2(ty-y,tx-x);
            for (double offset:new double[]{-.55,.55}) c.drawLine(tx,ty,tx-(float)Math.cos(angle+offset)*dp(22),ty-(float)Math.sin(angle+offset)*dp(22),paint);
            paint.setStyle(Paint.Style.FILL); paint.setTextSize(dp(15)); c.drawText("选子",x+dp(16),y,paint); c.drawText("落点",tx+dp(15),ty,paint);
        }
    }
}
