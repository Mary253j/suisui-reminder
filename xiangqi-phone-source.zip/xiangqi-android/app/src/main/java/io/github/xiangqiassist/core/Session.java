package io.github.xiangqiassist.core;

import java.util.*;

/** Only legal, observed transitions advance the engine's game history. */
public final class Session {
    public final String initialFen;
    private Position position;
    private final List<String> moves=new ArrayList<>();
    public Session(Position position) {
        if (!position.problems().isEmpty()) throw new IllegalArgumentException(String.join("；",position.problems()));
        this.position=position; this.initialFen=position.fen();
    }
    public Position position() { return position; }
    public List<String> history() { return new ArrayList<>(moves); }
    private void accept(Position.Move m) { position=position.apply(m); moves.add(m.toString()); }
    public boolean observe(String board) {
        if (board.equals(position.board)) return false;
        Position.Move m=position.transition(board);
        if (m==null) throw new IllegalStateException("局面变化不是一步合法走棋，请暂停后重新预览");
        accept(m); return true;
    }
    public boolean verifyMove(Position.Move planned,String board) {
        if (!position.legal(planned)) throw new IllegalArgumentException("计划走法非法");
        Position expected=position.apply(planned);
        if (board.equals(expected.board)) { accept(planned); return true; }
        Position.Move reply=expected.transition(board);
        if (reply!=null) { accept(planned); accept(reply); return true; }
        return false;
    }
}
