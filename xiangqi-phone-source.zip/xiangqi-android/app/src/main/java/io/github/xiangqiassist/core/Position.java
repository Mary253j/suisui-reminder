package io.github.xiangqiassist.core;

import java.util.*;

/** Canonical board: black at the top, red at the bottom; UCI a0 is bottom left. */
public final class Position {
    public static final String START = "rnbakabnr/9/1c5c1/p1p1p1p1p/9/9/P1P1P1P1P/1C5C1/9/RNBAKABNR w - - 0 1";
    public final String board;
    public final char side;
    public final int halfmove, fullmove;

    public Position(String board, char side) { this(board, side, 0, 1); }
    public Position(String board, char side, int halfmove, int fullmove) {
        if (board.length() != 90 || (side != 'w' && side != 'b')) throw new IllegalArgumentException("棋盘或行棋方无效");
        for (char p : board.toCharArray()) if (".KABNRCPkabnrcp".indexOf(p) < 0) throw new IllegalArgumentException("未知棋子");
        this.board = board; this.side = side; this.halfmove = halfmove; this.fullmove = fullmove;
    }
    public static char other(char side) { return side == 'w' ? 'b' : 'w'; }
    public static char color(char p) { return Character.isUpperCase(p) ? 'w' : 'b'; }
    public static String name(char p) {
        int n = "KABNRCPkabnrcp".indexOf(p);
        return n < 0 ? "空" : "帅仕相马车炮兵将士象马车炮卒".substring(n, n+1);
    }
    public static String square(int i) { return ""+(char)('a'+i%9)+(9-i/9); }

    public static final class Move {
        public final int from, to;
        public Move(int from, int to) { this.from = from; this.to = to; }
        public static Move parse(String s) {
            if (s == null || !s.matches("[a-i][0-9][a-i][0-9]")) throw new IllegalArgumentException("无效走法: "+s);
            return new Move((9-(s.charAt(1)-'0'))*9+s.charAt(0)-'a', (9-(s.charAt(3)-'0'))*9+s.charAt(2)-'a');
        }
        @Override public String toString() { return square(from)+square(to); }
        @Override public boolean equals(Object o) { return o instanceof Move && ((Move)o).from == from && ((Move)o).to == to; }
        @Override public int hashCode() { return from*90+to; }
    }

    public static Position fromFen(String fen) {
        String[] fields = fen.split(" ");
        if (fields.length < 2) throw new IllegalArgumentException("FEN 缺少行棋方");
        StringBuilder b = new StringBuilder();
        String[] rows = fields[0].replace('h','n').replace('H','N').replace('e','b').replace('E','B').split("/");
        if (rows.length != 10) throw new IllegalArgumentException("FEN 必须有十行");
        for (String row : rows) {
            int before = b.length();
            for (char p : row.toCharArray()) {
                if (p >= '1' && p <= '9') for (int i=0; i<p-'0'; i++) b.append('.');
                else b.append(p);
            }
            if (b.length()-before != 9) throw new IllegalArgumentException("FEN 每行九列");
        }
        return new Position(b.toString(), fields[1].charAt(0), fields.length>4?Integer.parseInt(fields[4]):0,
                fields.length>5?Integer.parseInt(fields[5]):1);
    }
    public String fen() {
        StringBuilder s = new StringBuilder();
        for (int r=0; r<10; r++) {
            int empty=0;
            for (int c=0; c<9; c++) {
                char p=board.charAt(r*9+c);
                if (p == '.') empty++;
                else { if (empty>0) s.append(empty); empty=0; s.append(p); }
            }
            if (empty>0) s.append(empty);
            if (r<9) s.append('/');
        }
        return s+" "+side+" - - "+halfmove+" "+fullmove;
    }
    public Position apply(Move m) {
        char[] b=board.toCharArray();
        char moving=b[m.from], taken=b[m.to];
        b[m.to]=moving; b[m.from]='.';
        return new Position(new String(b), other(side), taken!='.'||Character.toLowerCase(moving)=='p'?0:halfmove+1,
                fullmove+(side=='b'?1:0));
    }
    private boolean pseudo(int from, int to) {
        if (from==to) return false;
        char p=board.charAt(from), t=board.charAt(to);
        if (p=='.' || (t!='.' && color(p)==color(t))) return false;
        int r=from/9, c=from%9, rr=to/9, cc=to%9, dr=rr-r, dc=cc-c, ar=Math.abs(dr), ac=Math.abs(dc);
        char side=color(p), kind=Character.toLowerCase(p);
        if ((kind=='r'||kind=='c') && (dr==0||dc==0)) {
            int step=dr==0?Integer.signum(dc):9*Integer.signum(dr), between=0;
            for (int j=from+step; j!=to; j+=step) if (board.charAt(j)!='.') between++;
            return between==((kind=='c'&&t!='.')?1:0);
        }
        if (kind=='n' && ar+ac==3 && Math.min(ar,ac)==1) {
            int leg=from+(ar==2?9*Integer.signum(dr):Integer.signum(dc));
            return board.charAt(leg)=='.';
        }
        if (kind=='b' && ar==2 && ac==2)
            return board.charAt((r+dr/2)*9+c+dc/2)=='.' && (side=='w'?rr>=5:rr<=4);
        if (kind=='a'||kind=='k') {
            boolean palace=cc>=3&&cc<=5&&(side=='w'?rr>=7:rr<=2);
            if (palace && (kind=='a'?ar==1&&ac==1:ar+ac==1)) return true;
            if (kind=='k' && dc==0 && Character.toLowerCase(t)=='k') {
                int step=9*Integer.signum(dr);
                for (int j=from+step; j!=to; j+=step) if (board.charAt(j)!='.') return false;
                return true;
            }
        }
        return kind=='p' && ((dr==(side=='w'?-1:1)&&dc==0) || (dr==0&&ac==1&&(side=='w'?r<=4:r>=5)));
    }
    public boolean inCheck(char side) {
        int k=board.indexOf(side=='w'?'K':'k');
        if (k<0) return true;
        for (int i=0; i<90; i++) if (board.charAt(i)!='.' && color(board.charAt(i))!=side && pseudo(i,k)) return true;
        return false;
    }
    public boolean legal(Move m) {
        return m.from>=0&&m.from<90&&m.to>=0&&m.to<90 && board.charAt(m.from)!='.' && color(board.charAt(m.from))==side
                && pseudo(m.from,m.to) && !apply(m).inCheck(side);
    }
    public List<Move> legalMoves() {
        List<Move> result=new ArrayList<>();
        for (int i=0; i<90; i++) if (board.charAt(i)!='.'&&color(board.charAt(i))==side)
            for (int j=0; j<90; j++) { Move m=new Move(i,j); if (legal(m)) result.add(m); }
        return result;
    }
    public Move transition(String observed) {
        if (observed.length()!=90) return null;
        int changes=0, from=-1, to=-1;
        for (int i=0; i<90; i++) if (board.charAt(i)!=observed.charAt(i)) {
            changes++;
            if (board.charAt(i)!='.' && color(board.charAt(i))==side && observed.charAt(i)=='.') from=i;
            else to=i;
        }
        if (changes!=2 || from<0 || to<0 || observed.charAt(to)!=board.charAt(from)) return null;
        Move m=new Move(from,to);
        return legal(m)?m:null;
    }
    public List<String> problems() {
        List<String> errors=new ArrayList<>();
        String symbols="KABNRCPkabnrcp"; int[] limits={1,2,2,2,2,2,5,1,2,2,2,2,2,5};
        for (int j=0; j<symbols.length(); j++) {
            char p=symbols.charAt(j); int count=0;
            for (int i=0; i<90; i++) if (board.charAt(i)==p) count++;
            if (count>limits[j] || (Character.toLowerCase(p)=='k'&&count!=1)) errors.add(name(p)+"数量异常");
        }
        for (int i=0; i<90; i++) {
            char p=board.charAt(i), k=Character.toLowerCase(p);
            int rr=Character.isUpperCase(p)?9-i/9:i/9, c=i%9;
            if (k=='k' && !(rr<=2&&c>=3&&c<=5)) errors.add("将帅不在九宫");
            if (k=='a' && !((rr==1&&c==4)||((rr==0||rr==2)&&(c==3||c==5)))) errors.add("士仕位置异常");
            if (k=='b' && !((rr==0||rr==4)&&(c==2||c==6)||rr==2&&(c==0||c==4||c==8))) errors.add("象相位置异常");
            if (k=='p' && (rr<3 || (rr<=4&&c%2==1))) errors.add("兵卒位置异常");
        }
        if (errors.isEmpty()&&inCheck(other(side))) errors.add("非行棋方仍被将军，请检查当前轮到谁走");
        return errors;
    }
}
