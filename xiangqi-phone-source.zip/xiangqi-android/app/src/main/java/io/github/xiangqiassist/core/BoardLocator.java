package io.github.xiangqiassist.core;

import java.util.concurrent.atomic.AtomicBoolean;

/** Finds this board skin by its gold playing area and regular 9 by 10 line grid. */
public final class BoardLocator {
    private static void check(AtomicBoolean cancel) throws InterruptedException {
        if(cancel.get()||Thread.currentThread().isInterrupted()) throw new InterruptedException("已暂停");
    }
    public static Grid find(Recognizer.Frame frame,boolean redBottom,AtomicBoolean cancel) throws InterruptedException {
        double scale=Math.min(1,600.0/frame.width);
        int w=(int)Math.round(frame.width*scale),h=(int)Math.round(frame.height*scale);
        boolean[] gold=new boolean[w*h]; float[] light=new float[w*h];
        int[] rows=new int[h]; int max=0;
        for(int y=0;y<h;y++) {
            check(cancel);
            for(int x=0;x<w;x++) {
                int c=frame.sample(x/scale,y/scale),r=(c>>16)&255,g=(c>>8)&255,b=c&255;
                light[y*w+x]=(r+g+b)/3f;
                gold[y*w+x]=r>95&&r>g*1.08&&g>b*1.15&&r<g*1.9;
                if(gold[y*w+x]&&x>w*.04&&x<w*.96) rows[y]++;
            }
            max=Math.max(max,rows[y]);
        }
        if(max<w*.4) throw new IllegalArgumentException("没找到金色棋盘，请用方框调整位置");
        boolean[] band=new boolean[h]; int last=-10000;
        for(int y=0;y<h;y++) if(rows[y]>max*.70) {
            band[y]=true;
            if(y-last<w*.025) for(int k=last+1;k<y;k++) band[k]=true;
            last=y;
        }
        Grid best=null; double bestScore=0;
        for(int start=0;start<h;start++) {
            if(!band[start]) continue;
            int end=start; while(end<h&&band[end]) end++;
            int top=start,bottom=end-1; start=end;
            if(bottom-top<w*.45) continue;
            int left=w,right=-1;
            for(int x=0;x<w;x++) {
                int n=0;for(int y=top;y<=bottom;y++) if(gold[y*w+x]) n++;
                if(n>(bottom-top)*.58) {left=Math.min(left,x);right=x;}
            }
            double span=right-left;
            if(span<w*.4||(bottom-top)/span<.85||(bottom-top)/span>1.3) continue;
            float[] vertical=new float[w],horizontal=new float[h];
            int pad=Math.max(2,(int)(span*.004));
            for(int x=Math.max(left+pad,pad);x<Math.min(right-pad,w-pad);x++) {
                double sum=0;int n=0;
                for(int y=top+(int)(span*.05);y<bottom-span*.05;y+=2) {
                    int i=y*w+x;
                    sum+=Math.max(0,(light[i-pad]+light[i+pad])*.5-light[i]);n++;
                }
                vertical[x]=(float)(sum/Math.max(1,n));
            }
            double[] xf=fit(vertical,left+span*.025,left+span*.11,span*.098,span*.12,9,left+span*.88,left+span*.98,cancel);
            if(xf==null) continue;
            double dx=xf[1];
            for(int y=Math.max(top+pad,pad);y<Math.min(bottom-pad,h-pad);y++) {
                double sum=0;int n=0;
                for(int x=(int)(xf[0]+dx*.3);x<xf[0]+dx*7.7;x+=2) {
                    int i=y*w+x;
                    sum+=Math.max(0,(light[i-pad*w]+light[i+pad*w])*.5-light[i]);n++;
                }
                horizontal[y]=(float)(sum/Math.max(1,n));
            }
            double[] yf=fit(horizontal,top+span*.015,top+span*.12,dx*.90,dx*1.06,10,bottom-span*.11,bottom-span*.005,cancel);
            if(yf==null||xf[2]<1.5||yf[2]<1.5) continue;
            double score=xf[2]+yf[2];
            if(score>bestScore) {
                Grid g=new Grid(xf[0]/scale,yf[0]/scale,(xf[0]+8*dx)/scale,(yf[0]+9*yf[1])/scale,redBottom);
                try {g.validate(frame.width,frame.height);best=g;bestScore=score;} catch(IllegalArgumentException ignored) {}
            }
        }
        if(best==null) throw new IllegalArgumentException("棋盘线不够清晰，请拖动方框后确认");
        return best;
    }
    private static double[] fit(float[] values,double lo,double hi,double slo,double shi,int count,double endLo,double endHi,AtomicBoolean cancel) throws InterruptedException {
        double[] best=null;double score=-1;
        for(double start=lo;start<=hi;start+=.5) {
            check(cancel);
            for(double step=slo;step<=shi;step+=.1) {
                double end=start+(count-1)*step;
                if(end<endLo||end>endHi) continue;
                double sum=0;int hits=0;
                for(int k=1;k<count-1;k++) {
                    double pos=start+k*step;int a=(int)pos;
                    if(a<0||a+1>=values.length) continue;
                    double value=values[a]*(1-pos+a)+values[a+1]*(pos-a);
                    sum+=value;if(value>1.5) hits++;
                }
                double s=sum/(count-2);
                if(hits>=count-4&&s>score) {score=s;best=new double[]{start,step,s};}
            }
        }
        return best;
    }
}
