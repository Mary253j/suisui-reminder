package io.github.xiangqiassist;

import android.content.Context;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import io.github.xiangqiassist.core.UciEngine;

final class EngineFiles {
    static UciEngine open(Context context,AtomicBoolean cancel) throws Exception {
        File executable=new File(context.getApplicationInfo().nativeLibraryDir,"libpikafish.so");
        if (!executable.isFile()||!executable.canExecute()) throw new IOException("安装包缺少可执行的 ARM64 皮卡鱼引擎");
        File dir=new File(context.getFilesDir(),"engine");
        if (!dir.isDirectory()&&!dir.mkdirs()) throw new IOException("无法建立引擎目录");
        Properties meta=new Properties();
        try (InputStream in=context.getAssets().open("engine/engine.properties")) { meta.load(in); }
        String expected=meta.getProperty("network.sha256","");
        File network=new File(dir,"pikafish.nnue"), marker=new File(dir,"network.sha256");
        String current="";
        if (marker.isFile()) try (BufferedReader r=new BufferedReader(new FileReader(marker))) { current=r.readLine(); }
        if (!network.isFile()||!expected.equals(current)) {
            File temp=new File(dir,"network.tmp"); MessageDigest digest=MessageDigest.getInstance("SHA-256");
            try (InputStream in=context.getAssets().open("engine/pikafish.nnue"); OutputStream out=new FileOutputStream(temp)) {
                byte[] buf=new byte[65536]; int n;
                while ((n=in.read(buf))>=0) { if (cancel.get()) throw new InterruptedException("已暂停"); out.write(buf,0,n); digest.update(buf,0,n); }
            }
            StringBuilder hex=new StringBuilder(); for (byte b:digest.digest()) hex.append(String.format(Locale.ROOT,"%02x",b&255));
            if (!hex.toString().equals(expected)) { temp.delete(); throw new IOException("NNUE 校验失败"); }
            if (!temp.renameTo(network)) throw new IOException("无法保存 NNUE");
            try (Writer out=new FileWriter(marker)) { out.write(expected); }
        }
        return new UciEngine(Collections.singletonList(executable.getAbsolutePath()),dir,network.getAbsolutePath(),cancel);
    }
}
