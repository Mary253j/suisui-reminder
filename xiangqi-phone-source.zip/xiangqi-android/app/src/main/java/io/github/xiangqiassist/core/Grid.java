package io.github.xiangqiassist.core;

public final class Grid {
    public final double x0,y0,x8,y9;
    public final boolean redBottom;
    public Grid(double x0,double y0,double x8,double y9,boolean redBottom) {
        this.x0=x0; this.y0=y0; this.x8=x8; this.y9=y9; this.redBottom=redBottom;
    }
    public double dx() { return (x8-x0)/8; }
    public double dy() { return (y9-y0)/9; }
    public double x(int index) { return x0+(redBottom?index%9:8-index%9)*dx(); }
    public double y(int index) { return y0+(redBottom?index/9:9-index/9)*dy(); }
    public void validate(int width,int height) {
        if (!Double.isFinite(x0+y0+x8+y9) || dx()<22 || dy()<22 || dx()/dy()<.7 || dx()/dy()>1.35)
            throw new IllegalArgumentException("请按顺序标出左上、右下交叉点，棋盘需九列十行");
        if (x0<0||y0<0||x8>=width||y9>=height)
            throw new IllegalArgumentException("棋盘超出画面，请重新校准");
    }
}
