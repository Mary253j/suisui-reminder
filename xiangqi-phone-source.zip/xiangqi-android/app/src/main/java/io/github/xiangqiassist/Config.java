package io.github.xiangqiassist;

import android.content.*;
import io.github.xiangqiassist.core.Grid;

final class Config {
    final SharedPreferences prefs;
    Config(Context context) { prefs=context.getSharedPreferences("settings",Context.MODE_PRIVATE); }
    boolean auto() { return prefs.getBoolean("auto",false); }
    boolean redBottom() { return prefs.getBoolean("redBottom",true); }
    char ours() { return prefs.getBoolean("oursRed",true)?'w':'b'; }
    char turn() { return prefs.getBoolean("turnRed",true)?'w':'b'; }
    int think() { return prefs.getInt("think",1500); }
    String target() { return prefs.getString("target",""); }
    Grid grid(int width,int height) {
        if (!prefs.getBoolean("calibrated",false) || prefs.getInt("width",0)!=width || prefs.getInt("height",0)!=height)
            throw new IllegalStateException("请先校准棋盘；屏幕方向和尺寸变化后需重新校准");
        Grid g=new Grid(prefs.getFloat("x0",0),prefs.getFloat("y0",0),prefs.getFloat("x8",0),prefs.getFloat("y9",0),redBottom());
        g.validate(width,height); return g;
    }
    void calibrate(Grid g,int width,int height,String target) {
        g.validate(width,height);
        prefs.edit().putFloat("x0",(float)g.x0).putFloat("y0",(float)g.y0).putFloat("x8",(float)g.x8).putFloat("y9",(float)g.y9)
                .putInt("width",width).putInt("height",height).putBoolean("calibrated",true).putString("target",target).apply();
    }
    void save(boolean auto,boolean redBottom,boolean oursRed,boolean turnRed,int think) {
        SharedPreferences.Editor e=prefs.edit();
        if (redBottom!=redBottom()) e.putBoolean("calibrated",false);
        e.putBoolean("auto",auto).putBoolean("redBottom",redBottom).putBoolean("oursRed",oursRed).putBoolean("turnRed",turnRed)
                .putInt("think",think).apply();
    }
}
