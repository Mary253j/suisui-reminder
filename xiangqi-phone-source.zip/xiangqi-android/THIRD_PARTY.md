# 第三方内容

Pikafish 官方项目：<https://github.com/official-pikafish/Pikafish>，GPL v3。

本源码包未内置引擎二进制。`prepare_engine.py` 默认下载并校验 2026-09-06 官方发布包，将 Android ARM64 可执行文件、匹配 NNUE、对应完整源码压缩包和许可证一起加入应用资产。构建出的安装包中包含这些材料。重新分发时保留原始许可证及对应源码，并遵循上游要求。

本项目通过外部进程 UCI 调用引擎，未修改皮卡鱼源代码。Java 棋盘识别与控制实现由本项目提供。

Android 构建工具和 Gradle 由各自官方仓库下载，受对应许可证约束。py7zr 仅用于构建时解压官方发布包，使用 LGPL-2.1-or-later。手机运行时不需要 Python 或 py7zr。

参考图片由用户提供，保留在 `tests/fixtures/` 中用于验证；字形模板根据这些图片生成。
