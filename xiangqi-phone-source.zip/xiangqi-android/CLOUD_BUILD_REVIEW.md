# 待批准的云端构建

目标：在 GitHub Actions 编译、签名检查并打包可以安装的 `XiangqiPhone-debug.apk`。

候选仓库：`Mary253j/suisui-reminder`（公开）。

计划分支：`codex/xiangqi-apk-build`，从当前主分支建立独立分支。

该分支只增加两个文件：

1. `xiangqi-phone-source.zip`：安卓源码、棋子字形模板、构建工具和不含原始图片的测试。原始三张截图留在本地，不进入该压缩包。
2. `.github/workflows/xiangqi-phone-build.yml`：仅匹配该分支和上述构建文件的 GitHub Actions 工作流。

提交后触发云端构建，失败时在同一分支修复并重试。主分支及原应用的文件保持原样。构建过程下载官方 Android 工具与已固定版本、校验值的皮卡鱼，输出 APK artifact，保留 14 天。

由于候选仓库为公开仓库，上传的安卓源码与字形模板也会公开。这项公开发布需要用户明确批准。尚未向该仓库写入任何文件，也尚未开始远程构建。

若希望源码保持私有，可改用用户指定、已授权访问的私有仓库。
