# 已授权的云端构建

2026-10-29，用户明确回复：“允许，使用独立分支构建”。

公开仓库：`Mary253j/suisui-reminder`。独立分支：`codex/xiangqi-apk-build`。

该分支只增加两个文件：

1. `xiangqi-phone-source.zip`：Android 源码、字形模板及构建工具；原始三张截图留在本地。
2. `.github/workflows/xiangqi-phone-build.yml`：该分支专用构建工作流。

完整 Android SDK 编译、APK 签名和内容检查已成功。构建产物 `XiangqiPhone-APK` 保留 14 天。修复在同一分支完成，主分支和原应用未改动。

[构建与下载记录](https://github.com/Mary253j/suisui-reminder/actions/workflows/xiangqi-phone-build.yml)
