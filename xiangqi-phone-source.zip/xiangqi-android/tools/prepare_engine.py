"""Package an official Android ARM64 Pikafish executable as an installed native library.

Android 10+ does not allow executing downloaded binaries from an app's writable
files directory. The engine must be packaged before the APK is built.
"""
from __future__ import annotations
import argparse
import hashlib
import pathlib
import shutil
import struct
import subprocess
import sys
import tarfile
import zipfile
import time
from urllib.request import Request, urlopen

ROOT=pathlib.Path(__file__).resolve().parents[1]
VERSION='2026-09-06'
RELEASE='https://github.com/official-pikafish/Pikafish/releases/download/Pikafish-2026-09-06/Pikafish.2026-09-06.7z'
SHA256='41952bbfe2520faceb5902c69e6ab4845cc999841d2b49a95cc1be7867a25e5b'
SOURCE='https://github.com/official-pikafish/Pikafish/archive/refs/tags/Pikafish-2026-09-06.tar.gz'

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

def download(url,path,max_bytes=200*1024*1024):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.part')
    start=time.monotonic(); last=start; total=0
    print('Downloading:',url,flush=True)
    try:
        with urlopen(Request(url,headers={'User-Agent':'XiangqiPhone-build/0.1'}),timeout=30) as r,temp.open('wb') as out:
            while True:
                block=r.read(512*1024)
                if not block: break
                out.write(block); total+=len(block)
                if total>max_bytes or time.monotonic()-start>600: raise RuntimeError('Download size/time limit exceeded')
                if time.monotonic()-last>2:
                    print(f'  {total/1024/1024:.1f} MB',flush=True);last=time.monotonic()
        temp.replace(path)
    finally: temp.unlink(missing_ok=True)

def extract(archive,destination):
    destination.mkdir(parents=True,exist_ok=True)
    seven=shutil.which('7z') or shutil.which('7za')
    if seven:
        subprocess.run([seven,'x',str(archive),'-o'+str(destination),'-y'],check=True)
        return
    deps=ROOT/'.tools/python'
    sys.path.insert(0,str(deps))
    try: import py7zr
    except ImportError:
        subprocess.run([sys.executable,'-m','pip','install','--target',str(deps),'--timeout','20','--retries','1','py7zr>=1.0,<2'],check=True,timeout=240)
        import py7zr
    with py7zr.SevenZipFile(archive,'r') as z:
        for name in z.getnames():
            p=pathlib.PurePosixPath(name.replace('\\','/'))
            if p.is_absolute() or '..' in p.parts or ':' in name: raise RuntimeError('Unsafe archive path')
        z.extractall(destination)

def inspect_elf(path):
    data=path.read_bytes()
    if len(data)<64 or data[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<H',data,18)[0]!=183:
        raise RuntimeError(f'Not a little-endian Android ARM64 ELF executable: {path}')
    if struct.unpack_from('<H',data,16)[0] not in (2,3): raise RuntimeError('ELF is not executable/PIE')
    off=struct.unpack_from('<Q',data,32)[0]; size,num=struct.unpack_from('<HH',data,54)
    aligned=True; interpreter=None
    if size<56 or off+size*num>len(data): raise RuntimeError('Invalid ELF program headers')
    for i in range(num):
        pos=off+i*size
        if struct.unpack_from('<I',data,pos)[0]==1:
            file_offset,vaddr=struct.unpack_from('<QQ',data,pos+8)
            alignment=struct.unpack_from('<Q',data,pos+48)[0]
            aligned &= alignment>=16384 and file_offset%16384==vaddr%16384
        if struct.unpack_from('<I',data,pos)[0]==3:
            start=struct.unpack_from('<Q',data,pos+8)[0]
            length=struct.unpack_from('<Q',data,pos+32)[0]
            interpreter=data[start:start+length].rstrip(b'\0').decode('ascii')
    if interpreter is not None and interpreter not in ('/system/bin/linker64','/apex/com.android.runtime/bin/linker64'):
        raise RuntimeError('Not an Android dynamic linker: '+interpreter)
    # Official Android static executables have no PT_INTERP segment. Their
    # platform provenance is checked against Android entries in the verified release.
    print('ELF interpreter:',interpreter or 'none (static executable)',flush=True)
    return bool(aligned)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive',type=pathlib.Path,help='Official 2026-09-06 .7z downloaded manually')
    parser.add_argument('--binary',type=pathlib.Path,help='Explicit Android ARM64 executable from that release')
    parser.add_argument('--network',type=pathlib.Path,help='Matching NNUE from that release')
    parser.add_argument('--source-archive',type=pathlib.Path,help='Official matching source .tar.gz')
    args=parser.parse_args()
    cache=ROOT/'engine-download'; cache.mkdir(exist_ok=True)
    archive=args.archive or cache/f'Pikafish.{VERSION}.7z'
    if not archive.is_file():
        if args.archive: raise FileNotFoundError(archive)
        download(RELEASE,archive)
    if digest(archive)!=SHA256: raise RuntimeError('Official release SHA-256 mismatch')
    unpacked=cache/'unpacked'; extract(archive.resolve(),unpacked.resolve())
    files=[p for p in unpacked.rglob('*') if p.is_file()]
    candidates=[p for p in files if 'android' in str(p.relative_to(unpacked)).lower() and any(a in str(p.relative_to(unpacked)).lower() for a in ('arm64','aarch64','armv8'))
                and 'pikafish' in p.name.lower() and p.suffix.lower() not in ('.txt','.md','.nnue','.zip','.7z')]
    android_hashes={digest(p) for p in candidates}
    baseline=[p for p in candidates if not any(a in p.name.lower() for a in ('dotprod','sve','armv8.2','armv8_2'))]
    if len(baseline)==1: candidates=baseline
    binary=args.binary
    if binary is None:
        if len(candidates)!=1: raise RuntimeError('Select the Android ARM64 binary with --binary. Candidates: '+', '.join(str(p) for p in candidates))
        binary=candidates[0]
    networks=[p for p in files if p.suffix.lower()=='.nnue']
    network=args.network
    if network is None:
        if len(networks)!=1: raise RuntimeError('Select the matching .nnue with --network: '+', '.join(str(p) for p in networks))
        network=networks[0]
    # Explicit overrides must still match an actual file in the verified release.
    release_hashes={digest(p) for p in files if p.suffix.lower() not in ('.txt','.md')}
    if digest(binary) not in android_hashes or digest(network) not in release_hashes:
        raise RuntimeError('Binary is not an Android ARM64 entry, or NNUE is not part of the verified official release')
    print('Selected Android binary:',binary,flush=True)
    compatible=inspect_elf(binary)
    native=ROOT/'app/src/main/jniLibs/arm64-v8a'; assets=ROOT/'app/src/main/assets/engine'
    native.mkdir(parents=True,exist_ok=True);assets.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(binary,native/'libpikafish.so');shutil.copyfile(network,assets/'pikafish.nnue')
    source=args.source_archive or cache/'pikafish-source.tar.gz'
    if not source.is_file():
        if args.source_archive: raise FileNotFoundError(source)
        download(SOURCE,source,100*1024*1024)
    # Ship corresponding source and the upstream license together with the binary.
    # AAPT treats a trailing .gz as a compressed asset and may remove it.
    # Keep the untouched upstream source archive inside a normal ZIP asset.
    with zipfile.ZipFile(assets/'pikafish-source.zip','w',zipfile.ZIP_STORED) as bundle:
        bundle.write(source,'pikafish-source.tar.gz')
    with tarfile.open(source,'r:gz') as tar:
        copies=[m for m in tar.getmembers() if pathlib.PurePosixPath(m.name).name.lower() in ('copying','copying.txt','license','license.txt') and m.isfile()]
        if not copies: raise RuntimeError('Matching source archive has no license file')
        member=min(copies,key=lambda m:len(m.name)); stream=tar.extractfile(member)
        (assets/'COPYING.txt').write_bytes(stream.read())
    (assets/'engine.properties').write_text(f'version={VERSION}\nnetwork.sha256={digest(network)}\nexecutable.sha256={digest(binary)}\npage16k={str(compatible).lower()}\n','ascii')
    (assets/'SOURCE.txt').write_text(f'Official Pikafish {VERSION}\nGPL v3\n{SOURCE}\nSource is bundled as pikafish-source.zip (contains upstream tar.gz)\n','utf-8')
    print('Prepared ARM64 Pikafish:',binary)
    print('16 KB page alignment:',compatible)
    if not compatible: print('This binary needs a 4 KB-page Android device; rebuild upstream for a 16 KB-page device.')

if __name__=='__main__':
    try: main()
    except Exception as e: print('FAILED:',e,file=sys.stderr);sys.exit(1)
