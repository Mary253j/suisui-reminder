"""Build a debug-signed APK with a local Android SDK and pinned Gradle."""
from __future__ import annotations
import hashlib
import os
import pathlib
import shutil
import subprocess
import sys
import zipfile
from urllib.request import urlopen
from prepare_engine import ROOT,download

def find_sdk():
    for variable in ('ANDROID_HOME','ANDROID_SDK_ROOT'):
        if os.environ.get(variable):
            p=pathlib.Path(os.environ[variable])
            if p.is_dir(): return p
    props=ROOT/'local.properties'
    if props.is_file():
        for line in props.read_text('utf-8').splitlines():
            if line.startswith('sdk.dir='):
                p=pathlib.Path(line[8:].replace('\\:',':').replace('\\\\','\\'))
                if p.is_dir(): return p
    paths=[pathlib.Path.home()/'Android/Sdk',pathlib.Path.home()/'Library/Android/sdk']
    if os.environ.get('LOCALAPPDATA'): paths.append(pathlib.Path(os.environ['LOCALAPPDATA'])/'Android/Sdk')
    return next((p for p in paths if p.is_dir()),None)

def main():
    sdk=find_sdk()
    if sdk is None or not (sdk/'platforms/android-35/android.jar').is_file():
        raise RuntimeError('Install Android Studio and Android SDK Platform 35, then set ANDROID_HOME or open this project in Android Studio once.')
    env=os.environ.copy();env['ANDROID_HOME']=str(sdk)
    if not env.get('JAVA_HOME'):
        guesses=[pathlib.Path('/Applications/Android Studio.app/Contents/jbr/Contents/Home')]
        if env.get('ProgramFiles'): guesses.append(pathlib.Path(env['ProgramFiles'])/'Android/Android Studio/jbr')
        jdk=next((p for p in guesses if (p/'bin/java').exists() or (p/'bin/java.exe').exists()),None)
        if jdk: env['JAVA_HOME']=str(jdk)
    if not (ROOT/'app/src/main/jniLibs/arm64-v8a/libpikafish.so').exists() or not (ROOT/'app/src/main/assets/engine/pikafish.nnue').exists():
        subprocess.run([sys.executable,str(ROOT/'tools/prepare_engine.py')],check=True,cwd=ROOT)
    tools=ROOT/'.tools';tools.mkdir(exist_ok=True)
    version='8.9';folder=tools/f'gradle-{version}'
    if not folder.is_dir():
        url=f'https://services.gradle.org/distributions/gradle-{version}-bin.zip'
        archive=tools/f'gradle-{version}-bin.zip'
        if not archive.is_file(): download(url,archive,200*1024*1024)
        with urlopen(url+'.sha256',timeout=20) as response: expected=response.read(256).decode('ascii').strip().split()[0]
        actual=hashlib.sha256(archive.read_bytes()).hexdigest()
        if actual!=expected: raise RuntimeError('Gradle SHA-256 mismatch')
        with zipfile.ZipFile(archive) as z:
            for name in z.namelist():
                p=pathlib.PurePosixPath(name)
                if p.is_absolute() or '..' in p.parts: raise RuntimeError('Unsafe Gradle archive')
            z.extractall(tools)
    gradle=folder/'bin'/('gradle.bat' if os.name=='nt' else 'gradle')
    if os.name!='nt': gradle.chmod(gradle.stat().st_mode|0o111)
    subprocess.run([str(gradle),'--no-daemon','--console=plain','-g',str(tools/'gradle-cache'),':app:assembleDebug'],cwd=ROOT,env=env,check=True,timeout=1800)
    source=ROOT/'app/build/outputs/apk/debug/app-debug.apk'
    destination=ROOT/'XiangqiPhone-debug.apk';shutil.copyfile(source,destination)
    print('APK:',destination)
    print('SHA256:',hashlib.sha256(destination.read_bytes()).hexdigest())

if __name__=='__main__':
    try: main()
    except Exception as e: print('BUILD FAILED:',e,file=sys.stderr);sys.exit(1)
