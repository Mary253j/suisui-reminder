import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Parse all Android sources; this does not replace SDK compilation/type checking. */
public final class CheckSyntax {
    public static void main(String[] args) throws Exception {
        List<File> files=new ArrayList<>();
        try (java.util.stream.Stream<Path> paths=Files.walk(Paths.get(args[0]))) {
            paths.filter(p->p.toString().endsWith(".java")).forEach(p->files.add(p.toFile()));
        }
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null)throw new IllegalStateException("JDK compiler module required");
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,null,java.nio.charset.StandardCharsets.UTF_8)) {
            JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,Arrays.asList("-proc:none"),null,manager.getJavaFileObjectsFromFiles(files));
            task.parse();
            boolean failed=false;
            for(Diagnostic<?> d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR){System.err.println(d);failed=true;}
            if(failed)throw new IllegalStateException("Java parse failed");
        }
        System.out.println("Java syntax parsed: "+files.size()+" files (Android SDK type checking still required)");
    }
}
