"""Create the approved public build payload, excluding original screenshots."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json
root=Path(__file__).resolve().parents[1]
target=root.parent/'xiangqi-cloud-ready.zip'
with ZipFile(target,'w',ZIP_DEFLATED) as z:
    for path in sorted(root.rglob('*')):
        relative=path.relative_to(root)
        if not path.is_file() or any(p in {'.tools','.gradle','__pycache__','build','engine-download','fixtures','.github'} for p in relative.parts): continue
        if path.name=='local.properties' or path.suffix.lower() in ('.apk','.jpg','.jpeg','.png'): continue
        z.write(path,Path(root.name)/relative)
with ZipFile(target) as z: assert z.testzip() is None
print(json.dumps({'bytes':target.stat().st_size,'base64_length':4*((target.stat().st_size+2)//3),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
