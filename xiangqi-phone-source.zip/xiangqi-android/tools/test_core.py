"""Run Android-independent Java tests without Android SDK or Gradle."""
import pathlib
import subprocess
import sys

root=pathlib.Path(__file__).resolve().parents[1]
classes=root/'.tools/test-classes'
classes.mkdir(parents=True,exist_ok=True)
sources=list((root/'app/src/main/java/io/github/xiangqiassist/core').glob('*.java'))+list((root/'tests').glob('*.java'))
subprocess.run(['java','com.sun.tools.javac.Main','-source','8','-target','8','-encoding','UTF-8','-d',str(classes),*[str(p) for p in sources]],check=True)
extra=['--no-images'] if '--no-images' in sys.argv else []
subprocess.run(['java','-cp',str(classes),'CoreTests',str(root),sys.executable,*extra],check=True)
subprocess.run(['java','-cp',str(classes),'ControlTests'],check=True)
