@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
py -3 tools\build_apk.py
if errorlevel 1 goto fail
echo APK ready: XiangqiPhone-debug.apk
pause
exit /b 0
:fail
echo Build did not complete. See the error above and README.md.
pause
exit /b 1
