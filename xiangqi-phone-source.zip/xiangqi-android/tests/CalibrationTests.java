import io.github.xiangqiassist.core.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import java.util.concurrent.atomic.AtomicBoolean;

public final class CalibrationTests {
    private static int count;
    private static void check(boolean ok,String text) {if(!ok)throw new AssertionError(text);count++;System.out.println("PASS "+text);}
    private static Recognizer.Frame frame(BufferedImage image) {
        return new Recognizer.Frame(image.getWidth(),image.getHeight(),image.getRGB(0,0,image.getWidth(),image.getHeight(),null,0,image.getWidth()));
    }
    public static void main(String[] args) throws Exception {
        File root=new File(args[0]); AtomicBoolean cancel=new AtomicBoolean();
        new Grid(5,100,517,676,true).validate(582,1280);
        check(true,"visible grid near screen edge does not require extra outer padding");
        boolean outside=false;
        try {new Grid(-1,100,511,676,true).validate(582,1280);}catch(IllegalArgumentException expected){outside=true;}
        check(outside,"offscreen intersection still rejected");
        boolean reversed=false;
        try {new Grid(517,676,5,100,true).validate(582,1280);}catch(IllegalArgumentException expected){reversed=true;}
        check(reversed,"inverted adjustment cannot be confirmed");
        BufferedImage synthetic=new BufferedImage(600,1200,BufferedImage.TYPE_INT_RGB);
        Graphics2D s=synthetic.createGraphics();s.setColor(new Color(25,90,55));s.fillRect(0,0,600,1200);
        s.setColor(new Color(200,165,100));s.fillRect(8,300,584,650);
        s.setColor(new Color(112,85,60));s.setStroke(new BasicStroke(3));
        for(int c=0;c<9;c++)s.drawLine(44+c*64,340,44+c*64,916);
        for(int r=0;r<10;r++)s.drawLine(44,340+r*64,556,340+r*64);s.dispose();
        Grid found=BoardLocator.find(frame(synthetic),true,cancel);
        check(Math.abs(found.x0-44)<4&&Math.abs(found.y0-340)<4&&Math.abs(found.x8-556)<4&&Math.abs(found.y9-916)<4,"synthetic grid located without pieces");
        boolean rejected=false;
        try {BoardLocator.find(frame(new BufferedImage(600,1200,BufferedImage.TYPE_INT_RGB)),true,cancel);}catch(IllegalArgumentException expected){rejected=true;}
        check(rejected,"blank capture cannot silently become calibrated");
        cancel.set(true);boolean stopped=false;
        try {BoardLocator.find(frame(synthetic),true,cancel);}catch(InterruptedException expected){stopped=true;}
        check(stopped,"automatic calibration respects pause");cancel.set(false);
        if(args.length<2||!args[1].equals("--no-images")) {
            Recognizer recognizer=new Recognizer(new FileInputStream(new File(root,"app/src/main/assets/templates.bin")));
            for(String name:new String[]{"initial","selected","moved","calibration-error"}) {
                BufferedImage original=ImageIO.read(new File(root,"tests/fixtures/"+name+".jpg"));
                for(double scale:new double[]{.65,1,1.5}) {
                    BufferedImage scaled=new BufferedImage((int)Math.round(original.getWidth()*scale),(int)Math.round(original.getHeight()*scale),BufferedImage.TYPE_INT_RGB);
                    Graphics2D g=scaled.createGraphics();g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);g.drawImage(original,0,0,scaled.getWidth(),scaled.getHeight(),null);g.dispose();
                    Grid grid=recognizer.alignGrid(frame(scaled),BoardLocator.find(frame(scaled),true,cancel),cancel);
                    System.out.println("GRID "+name+" "+scale+": "+grid.x0+","+grid.y0+" - "+grid.x8+","+grid.y9);
                    check(Math.abs(grid.x0/scale-40)<5&&Math.abs(grid.x8/scale-544)<5&&Math.abs(grid.y0/scale-365)<5&&Math.abs(grid.y9/scale-912)<5,name+" automatic corners at scale "+scale);
                    Recognizer.Observation obs=recognizer.read(frame(scaled),grid,cancel);
                    Position p=Position.fromFen(Position.START);
                    if(name.equals("moved"))p=p.apply(Position.Move.parse("h0g2")).apply(Position.Move.parse("h7e7"));
                    System.out.println("RECOGNIZED "+obs.board.equals(p.board)+" issues "+obs.issues);
                    check(obs.board.equals(p.board)&&obs.issues.isEmpty(),name+" auto grid recognizes all 90 intersections at scale "+scale);
                }
                BufferedImage shifted=new BufferedImage(720,1420,BufferedImage.TYPE_INT_RGB);
                Graphics2D g=shifted.createGraphics();g.setColor(Color.BLACK);g.fillRect(0,0,720,1420);g.drawImage(original,61,53,null);g.dispose();
                Grid grid=BoardLocator.find(frame(shifted),false,cancel);
                check(Math.abs(grid.x0-101)<5&&Math.abs(grid.y0-418)<5&&!grid.redBottom,name+" letterbox and screen offset");
            }
        }
        System.out.println(count+" calibration checks passed");
    }
}
