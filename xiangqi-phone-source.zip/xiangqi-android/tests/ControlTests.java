import io.github.xiangqiassist.core.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ControlTests {
    private static final Position P=Position.fromFen(Position.START);
    private static final Position.Move MOVE=Position.Move.parse("h0g2"), REPLY=Position.Move.parse("h7e7");
    private static final Position Q=P.apply(MOVE), R=Q.apply(REPLY);
    private static int checks;
    private static void check(boolean value,String name) { if(!value)throw new AssertionError(name);checks++;System.out.println("PASS "+name); }
    private static Recognizer.Observation o(String board,Integer... lifted) { return new Recognizer.Observation(board,new float[90],Collections.emptyList(),new HashSet<>(Arrays.asList(lifted))); }
    private static final class Fake implements AutoPlayer.Environment {
        final List<Recognizer.Observation> frames; final List<Integer> taps=new ArrayList<>();
        final AtomicBoolean cancel=new AtomicBoolean(); int n=0; boolean available=true,stopAfterSource=false,stopOnHint=false;
        Position.Move hint; String status="";
        Fake(Recognizer.Observation... frames) { this.frames=Arrays.asList(frames); }
        @Override public Recognizer.Observation read() { return frames.get(Math.min(n++,frames.size()-1)); }
        @Override public boolean inputAvailable() { return available; }
        @Override public void tap(int index) { taps.add(index); if(stopAfterSource)cancel.set(true); }
        @Override public void hint(Position.Move move) { hint=move; if(move!=null&&stopOnHint)cancel.set(true); }
        @Override public void status(String text) { status=text; }
        @Override public void position(Position p) {}
        AutoPlayer player() { return new AutoPlayer(this,cancel,1,50); }
    }
    public static void main(String[] args) throws Exception {
        Fake normal=new Fake(o(P.board),o(P.board),o(P.board,MOVE.from),o(Q.board),o(Q.board));
        Session normalSession=new Session(P);
        check(normal.player().execute(normalSession,MOVE),"two-tap move verified");
        check(normal.taps.equals(Arrays.asList(MOVE.from,MOVE.to)),"source and destination order");
        check(normalSession.position().board.equals(Q.board),"only verified move commits");
        Fake fast=new Fake(o(P.board),o(P.board),o(P.board,MOVE.from),o(R.board),o(R.board));
        Session fastSession=new Session(P);
        check(fast.player().execute(fastSession,MOVE),"fast opponent reply accepted");
        check(fastSession.history().size()==2,"both observed plies retained");
        Fake selectionFailed=new Fake(o(P.board));
        check(!selectionFailed.player().execute(new Session(P),MOVE),"failed selection switches to reference hint");
        check(selectionFailed.taps.size()==1,"failed selection never clicks destination");
        check(MOVE.equals(selectionFailed.hint),"fallback retains computed suggestion");
        Fake destinationFailed=new Fake(o(P.board),o(P.board),o(P.board,MOVE.from),o(P.board));
        Session failed=new Session(P);
        check(!destinationFailed.player().execute(failed,MOVE),"unconfirmed destination pauses");
        check(destinationFailed.taps.size()==2&&failed.history().isEmpty(),"no retry or fictitious board advance");
        Fake stopped=new Fake(o(P.board)); stopped.cancel.set(true); boolean interrupted=false;
        try { stopped.player().execute(new Session(P),MOVE); } catch(InterruptedException e) { interrupted=true; }
        check(interrupted&&stopped.taps.isEmpty(),"cancel before source means no taps");
        Fake partial=new Fake(o(P.board)); partial.stopAfterSource=true; interrupted=false;
        try { partial.player().execute(new Session(P),MOVE); } catch(InterruptedException e) { interrupted=true; }
        check(interrupted&&partial.taps.size()==1,"cancel after source prevents destination");
        Fake changed=new Fake(o(Q.board)); boolean rejected=false;
        try { changed.player().execute(new Session(P),MOVE); } catch(IllegalStateException e) { rejected=true; }
        check(rejected&&changed.taps.isEmpty(),"stale computation never clicks");
        for(boolean automatic:new boolean[]{false,true}) {
            Fake hintOnly=new Fake(o(P.board)); hintOnly.available=false; hintOnly.stopOnHint=true;
            try { hintOnly.player().run(P.board,'w','w',automatic,()->new AutoPlayer.Brain(){
                public Position.Move bestMove(Session session) { return MOVE; }
                public void close() {}
            }); } catch(InterruptedException expected) {}
            check(hintOnly.taps.isEmpty()&&MOVE.equals(hintOnly.hint),automatic?"no accessibility falls back to hint":"hint-only never taps");
        }
        System.out.println("ALL "+checks+" CONTROL CHECKS PASSED");
    }
}
