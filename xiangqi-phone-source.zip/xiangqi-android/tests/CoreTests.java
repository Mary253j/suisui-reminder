import io.github.xiangqiassist.core.*;
import java.io.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class CoreTests {
    private static int count=0;
    private static void check(boolean value,String description) {
        if (!value) throw new AssertionError(description);
        count++; System.out.println("PASS "+description);
    }
    public static void main(String[] args) throws Exception {
        File root=new File(args[0]);
        Position p=Position.fromFen(Position.START);
        check(p.problems().isEmpty(),"initial position valid");
        check(p.fen().equals(Position.START),"FEN round trip");
        check(p.legalMoves().size()==44,"initial perft 1 = 44");
        int n=0; for (Position.Move m:p.legalMoves()) n+=p.apply(m).legalMoves().size();
        check(n==1920,"initial perft 2 = 1920");
        check(!p.legal(Position.Move.parse("b0d1")),"blocked horse leg");
        check(p.legal(Position.Move.parse("b2b9")),"cannon captures over one screen");
        check(!p.legal(Position.Move.parse("a0a9")),"rook cannot jump");
        Position pinned=Position.fromFen("4k4/9/9/9/4R4/9/9/9/9/4K4 w - - 0 1");
        check(!pinned.legal(Position.Move.parse("e5d5")),"flying generals and self-check");
        Position.Move move=Position.Move.parse("h0g2"),reply=Position.Move.parse("h7e7");
        Position q=p.apply(move),r=q.apply(reply);
        check(move.equals(p.transition(q.board)),"legal observed transition");
        check(p.transition(r.board)==null,"reject untracked two-ply jump");
        Session session=new Session(p);
        check(!session.verifyMove(move,p.board),"unchanged board never commits a move");
        check(session.verifyMove(move,r.board),"fast opponent reply is verified");
        check(session.history().equals(Arrays.asList("h0g2","h7e7")),"full move history preserved");
        check(!session.observe(r.board),"same frame does not repeat moves");
        Grid grid=new Grid(40,365,544,912,true);
        Grid reversed=new Grid(40,365,544,912,false);
        check(grid.x(89)==reversed.x(0)&&grid.y(89)==reversed.y(0),"flipped click mapping");
        Recognizer recognizer=new Recognizer(new FileInputStream(new File(root,"app/src/main/assets/templates.bin")));
        boolean skipImages=args.length>2&&args[2].equals("--no-images");
        if (!skipImages) {
        BufferedImage initialImage=ImageIO.read(new File(root,"tests/fixtures/initial.jpg"));
        for (double scale:new double[]{.65,1.5}) {
            int w=(int)Math.round(initialImage.getWidth()*scale),h=(int)Math.round(initialImage.getHeight()*scale);
            BufferedImage scaled=new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
            java.awt.Graphics2D graphics=scaled.createGraphics();
            graphics.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            graphics.drawImage(initialImage,0,0,w,h,null);graphics.dispose();
            Recognizer.Frame frame=new Recognizer.Frame(w,h,scaled.getRGB(0,0,w,h,null,0,w));
            Recognizer.Observation o=recognizer.read(frame,new Grid(40*scale,365*scale,544*scale,912*scale,true),new AtomicBoolean());
            check(o.board.equals(p.board)&&o.issues.isEmpty(),"scaled screenshot "+scale);
        }
        for (String name:new String[]{"initial","selected","moved"}) {
            BufferedImage image=ImageIO.read(new File(root,"tests/fixtures/"+name+".jpg"));
            Recognizer.Frame frame=new Recognizer.Frame(image.getWidth(),image.getHeight(),image.getRGB(0,0,image.getWidth(),image.getHeight(),null,0,image.getWidth()));
            Recognizer.Observation o=recognizer.read(frame,grid,new AtomicBoolean());
            check(o.board.equals(name.equals("moved")?r.board:p.board),name+" screenshot all 90 intersections");
            check(o.issues.isEmpty(),name+" screenshot confident: "+o.issues);
            check(name.equals("initial")?o.lifted.isEmpty():o.lifted.contains(name.equals("selected")?70:69),name+" selected-piece detection");
            AtomicBoolean cancelled=new AtomicBoolean(true);
            boolean stopped=false; try { recognizer.read(frame,grid,cancelled); } catch (InterruptedException e) { stopped=true; }
            check(stopped,"recognition respects cancellation");
        }
        } else System.out.println("Image regression skipped: reference screenshots remain local");
        File fixture=new File(root,"tests/fake_uci.py");
        AtomicBoolean cancel=new AtomicBoolean();
        try (UciEngine engine=new UciEngine(Arrays.asList(args[1],fixture.getAbsolutePath()),root,"",cancel)) {
            check(engine.name.equals("Protocol Test Fixture"),"UCI handshake");
            check(move.equals(engine.bestMove(new Session(p),100)),"UCI move parses and passes legal validation");
            cancel.set(true); boolean stopped=false;
            try { engine.bestMove(new Session(p),100); } catch (InterruptedException e) { stopped=true; }
            check(stopped,"UCI wait respects cancellation");
        }
        System.out.println("ALL "+count+" CHECKS PASSED");
    }
}
