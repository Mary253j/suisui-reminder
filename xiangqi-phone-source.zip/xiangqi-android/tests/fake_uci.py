"""Protocol fixture only. This is not a chess engine."""
import sys
import time

for command in sys.stdin:
    command = command.strip()
    if command == "uci":
        print("id name Protocol Test Fixture")
        print("option name Threads type spin default 1 min 1 max 128")
        print("option name Hash type spin default 16 min 1 max 8192")
        print("uciok", flush=True)
    elif command == "isready":
        print("readyok", flush=True)
    elif command.startswith("position"):
        if "broken" in command:
            print("info string CRITICAL ERROR: invalid position", flush=True)
            sys.exit(1)
        print("info string received "+command, flush=True)
    elif command.startswith("go"):
        time.sleep(.03)
        print("info depth 1 score cp 10 pv h0g2")
        print("bestmove h0g2 ponder h7e7", flush=True)
    elif command == "quit":
        sys.exit(0)
