@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
call setup.bat
if errorlevel 1 goto fail
".venv\Scripts\python.exe" app.py
if errorlevel 1 goto fail
exit /b 0
:fail
echo.
echo Startup failed. See the message above.
pause
exit /b 1
