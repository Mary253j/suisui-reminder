@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
call setup.bat
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install --timeout 20 --retries 1 "pyinstaller>=6,<7"
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --windowed --name XiangqiAutoPlayer --add-data "assets;assets" app.py
if errorlevel 1 goto fail
echo Output: dist\XiangqiAutoPlayer\XiangqiAutoPlayer.exe
echo Copy the entire XiangqiAutoPlayer folder. Select your engine on first launch.
pause
exit /b 0
:fail
echo Build failed. See the error above.
pause
exit /b 1
