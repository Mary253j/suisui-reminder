from pathlib import Path
import sys
import unittest
from xiangqi.device import StopToken
from xiangqi.engine import Pikafish, EngineError
from xiangqi.model import START_FEN


class EngineTests(unittest.TestCase):
    def make(self, **kwargs):
        return Pikafish([sys.executable, str(Path(__file__).with_name("fake_uci.py"))], **kwargs)

    def test_uci_handshake_and_position_history(self):
        with self.make() as engine:
            self.assertEqual("Protocol Test Fixture", engine.name)
            self.assertEqual("h0g2", engine.bestmove(START_FEN, ["b2e2", "b7e7"], 100))
            self.assertTrue(any("moves b2e2 b7e7" in s for s in engine.tail))
        self.assertIsNotNone(engine.process.poll())

    def test_critical_error_is_reported(self):
        with self.make() as engine:
            with self.assertRaisesRegex(EngineError, "CRITICAL ERROR"):
                engine.bestmove("broken", [], 100)

    def test_cancel_interrupts_wait(self):
        token = StopToken()
        with self.make(cancel=token) as engine:
            token.set()
            with self.assertRaises(InterruptedError):
                engine.bestmove(START_FEN, [], 100)


if __name__ == "__main__":
    unittest.main()
