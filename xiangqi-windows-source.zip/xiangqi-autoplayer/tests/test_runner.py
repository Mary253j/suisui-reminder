import unittest
from PIL import Image
from xiangqi.device import StopToken
from xiangqi.model import Position, START_FEN, Move
from xiangqi.runner import AutoPlayer, Settings
from xiangqi.vision import Observation, SAMPLE_GRID


P = Position.from_fen(START_FEN)
MOVE = Move.parse("h0g2")
Q = P.apply(MOVE)
REPLY = Move.parse("h7e7")
R = Q.apply(REPLY)


def observation(board, lifted=()):
    return Observation(board, (1.,)*90, (), lifted)

def uncertain_pawn(board, lifted=(), score=.5686):
    scores=[1.]*90;scores[54]=score
    return Observation(board,tuple(scores),("a3: P 匹配 0.57，差值 0.08",),lifted)


class FakeDevice:
    def __init__(self, frames):
        self.frames, self.index, self.taps = frames, 0, []

    def frame(self, grid):
        n = min(self.index, len(self.frames)-1)
        self.index += 1
        return self.frames[n], grid

    def tap(self, point, token):
        token.check()
        self.taps.append(point)


class FakeRecognizer:
    def read(self, image, grid):
        return image


class FakeEngine:
    name = "Runner Test Fixture"

    def __init__(self, *args, **kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def bestmove(self, *args):
        return MOVE.uci()


class RunnerTests(unittest.TestCase):
    def player(self, frames, timeout=.15):
        device = FakeDevice(frames)
        settings = Settings(SAMPLE_GRID, "fixture", poll_seconds=.001, click_gap=.001, verify_timeout=timeout)
        player = AutoPlayer(settings, device, FakeRecognizer(), engine_factory=FakeEngine)
        player.position, player.initial_fen = P, P.fen()
        return player, device

    def test_two_clicks_and_exact_verification(self):
        player, device = self.player([observation(P.board), observation(P.board),
            observation(P.board, (MOVE.src,)), observation(Q.board), observation(Q.board)])
        player._execute(MOVE)
        self.assertEqual([SAMPLE_GRID.point(MOVE.src), SAMPLE_GRID.point(MOVE.dst)], device.taps)
        self.assertEqual(Q, player.position)
        self.assertEqual([MOVE.uci()], player.history)

    def test_confirmed_pawn_can_remain_unchanged_across_verified_move(self):
        player, device = self.player([uncertain_pawn(P.board),uncertain_pawn(P.board),
            uncertain_pawn(P.board,(MOVE.src,)),uncertain_pawn(Q.board),uncertain_pawn(Q.board)])
        player.confirmed_cells={54:'P'}
        player._execute(MOVE)
        self.assertEqual(Q,player.position)
        self.assertEqual([SAMPLE_GRID.point(MOVE.src),SAMPLE_GRID.point(MOVE.dst)],device.taps)
        self.assertEqual({54:'P'},player.confirmed_cells)

    def test_unconfirmed_or_worsened_match_still_stops(self):
        for confirmed,score in (({},.5686),({54:'P'},.49)):
            with self.subTest(confirmed=confirmed,score=score):
                player,device=self.player([uncertain_pawn(P.board,score=score)])
                player.confirmed_cells=confirmed
                with self.assertRaisesRegex(RuntimeError,"稳定棋盘"):
                    player._stable(timeout=.02)
                self.assertFalse(device.taps)

    def test_confirmation_is_removed_when_confirmed_piece_moves(self):
        player,_=self.player([observation(P.board)])
        player.confirmed_cells={54:'P'}
        move=Move.parse('a3a4')
        self.assertIn(move,P.legal_moves())
        player._accept(move)
        self.assertNotIn(54,player.confirmed_cells)

    def test_fast_opponent_response(self):
        player, device = self.player([observation(P.board), observation(P.board),
            observation(P.board, (MOVE.src,)), observation(R.board), observation(R.board)])
        player._execute(MOVE)
        self.assertEqual(R, player.position)
        self.assertEqual([MOVE.uci(), REPLY.uci()], player.history)
        self.assertEqual(2, len(device.taps))

    def test_failed_move_never_reclicks(self):
        player, device = self.player([observation(P.board), observation(P.board),
            observation(P.board, (MOVE.src,)), observation(P.board)])
        with self.assertRaisesRegex(RuntimeError, "落子未通过"):
            player._execute(MOVE)
        self.assertEqual(2, len(device.taps))
        self.assertEqual(P, player.position)

    def test_failed_selection_never_clicks_destination(self):
        player, device = self.player([observation(P.board)])
        with self.assertRaisesRegex(RuntimeError, "未检测到计划棋子"):
            player._execute(MOVE)
        self.assertEqual([SAMPLE_GRID.point(MOVE.src)], device.taps)

    def test_changed_board_prevents_clicks(self):
        player, device = self.player([observation(Q.board)])
        with self.assertRaisesRegex(RuntimeError, "计算期间棋盘发生变化"):
            player._execute(MOVE)
        self.assertFalse(device.taps)

    def test_stop_prevents_all_clicks(self):
        player, device = self.player([observation(P.board)])
        player.token.set()
        with self.assertRaises(InterruptedError):
            player._execute(MOVE)
        self.assertFalse(device.taps)

    def test_stop_after_source_prevents_destination(self):
        player, device = self.player([observation(P.board)])
        original_tap = device.tap
        def tap_and_stop(point, token):
            original_tap(point, token)
            token.set()
        device.tap = tap_and_stop
        with self.assertRaises(InterruptedError):
            player._execute(MOVE)
        self.assertEqual([SAMPLE_GRID.point(MOVE.src)], device.taps)

    def test_analysis_never_clicks(self):
        player, device = self.player([observation(P.board)])
        player.run(P.board, analysis_only=True)
        self.assertFalse(device.taps)

    def test_selected_piece_cannot_arm(self):
        player, device = self.player([observation(P.board, (70,))])
        with self.assertRaisesRegex(RuntimeError, "稳定棋盘"):
            player._stable(timeout=.02)
        self.assertFalse(device.taps)


if __name__ == "__main__":
    unittest.main()
