import unittest
import numpy as np
from PIL import Image, ImageDraw
from xiangqi.vision import Grid, refine_grid, glyph, Observation, confirmable_cells, unresolved_issues
from xiangqi.model import Position, START_FEN


class CalibrationTests(unittest.TestCase):
    def test_only_moderately_uncertain_same_square_can_be_confirmed(self):
        board = Position.from_fen(START_FEN).board
        scores = [1.0]*90; scores[54] = .5686
        issue = "a3: P 匹配 0.57，差值 0.08"
        obs = Observation(board,tuple(scores),(issue,),())
        self.assertEqual({54:'P'},confirmable_cells(obs))
        self.assertEqual((),unresolved_issues(obs,{54:'P'}))
        self.assertEqual((issue,),unresolved_issues(obs,{}))
        self.assertEqual((issue,),unresolved_issues(obs,{54:'R'}))
        weaker = list(scores);weaker[54]=.49
        self.assertIsNone(confirmable_cells(Observation(board,tuple(weaker),(issue,),())))
        self.assertEqual((issue,),unresolved_issues(Observation(board,tuple(weaker),(issue,),()),{54:'P'}))
        slight_variation=list(scores);slight_variation[54]=.53
        self.assertEqual((),unresolved_issues(Observation(board,tuple(slight_variation),(issue,),()),{54:'P'}))
        ambiguous = "a3: P 匹配 0.57，差值 0.01"
        self.assertIsNone(confirmable_cells(Observation(board,tuple(scores),(ambiguous,),())))
        self.assertIsNone(confirmable_cells(Observation(board,tuple(scores),(issue,),(54,))))
        self.assertIsNone(confirmable_cells(Observation(board,tuple(scores),("自动微调前后局面不一致，请重新校准",),())))
        changed = list(board);changed[54]='R'
        self.assertEqual((issue,),unresolved_issues(Observation(tuple(changed),tuple(scores),(issue,),()),{54:'P'}))
    def test_vivid_red_marker_is_ignored_but_dark_red_glyph_is_kept(self):
        image = Image.new('RGB',(400,500),(215,180,130))
        grid = Grid(80,80,320,350)
        x,y=grid.point(40)
        y-=grid.dy*.075
        draw=ImageDraw.Draw(image)
        draw.rectangle((x-6,y-8,x-2,y+8),fill=(130,20,20))
        with_dark = glyph(image,grid,40)[0].sum()
        draw.rectangle((x+1,y-8,x+6,y+8),fill=(255,25,25))
        with_marker = glyph(image,grid,40)[0].sum()
        self.assertGreater(with_dark,10)
        # Antialiased boundaries may leave a little pigment; the ring must not
        # contribute enough to overwhelm a normal dark-red character.
        self.assertLess(abs(with_marker-with_dark),with_dark*.12)

    def test_adjusts_misaligned_grid_using_lines(self):
        image = Image.new('RGB',(616,674),(205,165,100))
        draw = ImageDraw.Draw(image)
        for i in range(9):
            x = 42+i*(538/8)
            draw.line((x,48,x,629),fill=(105,75,55),width=3)
        for i in range(10):
            y = 48+i*(581/9)
            draw.line((42,y,580,y),fill=(105,75,55),width=3)
        original = Grid(35,43,580,639)
        fitted = refine_grid(image,original)
        for actual, expected in zip((fitted.x0,fitted.y0,fitted.x8,fitted.y9),(42,48,580,629)):
            self.assertLess(abs(actual-expected),2)
        self.assertTrue(fitted.red_bottom)

    def test_blank_image_does_not_recalibrate(self):
        original = Grid(35,43,580,639,False)
        image = Image.fromarray(np.full((674,616,3),180,dtype=np.uint8))
        self.assertEqual(original,refine_grid(image,original))

if __name__ == '__main__':
    unittest.main()
