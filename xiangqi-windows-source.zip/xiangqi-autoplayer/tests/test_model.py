import unittest
from xiangqi.model import Position, Move, START_FEN


class RulesTests(unittest.TestCase):
    def test_initial_move_counts(self):
        p = Position.from_fen(START_FEN)
        self.assertEqual([], p.problems())
        moves = list(p.legal_moves())
        self.assertEqual(44, len(moves))
        self.assertEqual(1920, sum(len(list(p.apply(m).legal_moves())) for m in moves))

    def test_board_transition_and_history(self):
        p = Position.from_fen(START_FEN)
        for text in ("h0g2", "h7e7", "b2e2"):
            move = Move.parse(text)
            self.assertIn(move, p.legal_moves())
            q = p.apply(move)
            self.assertEqual(move, p.transition(q.board))
            self.assertEqual(q, Position.from_fen(q.fen()))
            p = q

    def test_horse_leg_and_cannon_screen(self):
        p = Position.from_fen(START_FEN)
        self.assertNotIn(Move.parse("b0d1"), p.legal_moves())
        self.assertIn(Move.parse("b2b9"), p.legal_moves())
        self.assertNotIn(Move.parse("a0a9"), p.legal_moves())

    def test_flying_generals_and_self_check(self):
        p = Position.from_fen("4k4/9/9/9/4R4/9/9/9/9/4K4 w - - 0 1")
        self.assertNotIn(Move.parse("e5d5"), p.legal_moves())
        self.assertIn(Move.parse("e5e6"), p.legal_moves())

    def test_corrupt_and_impossible_positions(self):
        p = Position.from_fen(START_FEN)
        b = list(p.board)
        b[0] = "K"
        self.assertTrue(Position(tuple(b)).problems())
        with self.assertRaises(ValueError):
            Position.from_fen("9/9 w")
        self.assertIsNone(p.transition(tuple("." for _ in range(90))))


if __name__ == "__main__":
    unittest.main()
