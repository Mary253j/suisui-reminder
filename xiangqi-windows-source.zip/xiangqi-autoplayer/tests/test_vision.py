from io import BytesIO
import unittest
from PIL import Image, ImageDraw
from xiangqi.model import Position, START_FEN, Move
from xiangqi.vision import ROOT, Recognizer, SAMPLE_GRID, Grid, refine_grid


class VisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reader = Recognizer()
        cls.initial = Position.from_fen(START_FEN)

    def read(self, name, grid=SAMPLE_GRID):
        return self.reader.read(Image.open(ROOT/f"assets/samples/{name}.jpg"), grid)

    def test_provided_three_screenshots(self):
        initial = self.read("initial")
        selected = self.read("selected")
        moved = self.read("moved")
        self.assertEqual(self.initial.board, initial.board)
        self.assertEqual(self.initial.board, selected.board)
        p = self.initial.apply(Move.parse("h0g2")).apply(Move.parse("h7e7"))
        self.assertEqual(p.board, moved.board)
        self.assertFalse(initial.issues+selected.issues+moved.issues)
        self.assertFalse(initial.lifted)
        self.assertEqual((70,), selected.lifted)

    def test_resize_jpeg_and_translated_crop(self):
        image = Image.open(ROOT/"assets/samples/initial.jpg")
        for factor in (.65, 1.5):
            with self.subTest(factor=factor):
                scaled = image.resize((round(image.width*factor), round(image.height*factor)))
                buf = BytesIO()
                scaled.save(buf, format="JPEG", quality=70)
                buf.seek(0)
                grid = Grid(*(v*factor for v in (40,365,544,912)))
                obs = self.reader.read(Image.open(buf), grid)
                self.assertEqual(self.initial.board, obs.board)
                self.assertFalse(obs.issues, obs.issues)
        box = SAMPLE_GRID.bbox()
        obs = self.reader.read(image.crop(box), SAMPLE_GRID.local(box[:2]))
        self.assertEqual(self.initial.board, obs.board)
        self.assertFalse(obs.issues)

    def test_reversed_view(self):
        # A flipped *layout*, as games render it: glyphs remain upright.
        image = Image.open(ROOT/"assets/samples/initial.jpg")
        reversed_grid = Grid(40,365,544,912,False)
        flipped = image.copy()
        for i, p in enumerate(self.initial.board):
            if p == ".":
                continue
            x,y = SAMPLE_GRID.point(i)
            target_x, target_y = reversed_grid.point(i)
            patch = image.crop((round(x-29),round(y-31),round(x+29),round(y+29)))
            flipped.paste(patch,(round(target_x-29),round(target_y-31)))
        obs = self.reader.read(flipped, reversed_grid)
        self.assertEqual(self.initial.board,obs.board)
        self.assertFalse(obs.issues, obs.issues)

    def test_invalid_calibration(self):
        with self.assertRaises(ValueError):
            Grid(500,900,40,365).validate()

    def test_colored_rings_do_not_change_the_initial_board(self):
        image=Image.open(ROOT/"assets/samples/initial.jpg").convert("RGB")
        for color in ((255,255,255),(255,25,25),(0,255,0)):
            for radius in (.35,.45,.55):
                for opacity in (160,255):
                  with self.subTest(color=color,radius=radius,opacity=opacity):
                    layer=Image.new('RGBA',image.size);draw=ImageDraw.Draw(layer)
                    for index in (0,19,27,54,70,85,40):
                        x,y=SAMPLE_GRID.point(index);r=SAMPLE_GRID.dx*radius
                        draw.ellipse((x-r,y-r,x+r,y+r),outline=(*color,opacity),width=3)
                    marked=Image.alpha_composite(image.convert('RGBA'),layer).convert('RGB')
                    obs=self.reader.read(marked,SAMPLE_GRID)
                    self.assertEqual(self.initial.board,obs.board)
                    self.assertFalse(obs.issues,obs.issues)
                    self.assertFalse(obs.lifted,obs.lifted)

    def test_opponent_move_with_white_ring_and_colored_hints(self):
        # The supplied moved screenshot has the opponent's actual white ring,
        # as well as a physically raised red horse. Restore that horse to its
        # normal height so the test models a completed opponent turn.
        initial=Image.open(ROOT/"assets/samples/initial.jpg").convert("RGB")
        image=Image.open(ROOT/"assets/samples/moved.jpg").convert("RGB")
        x,y=map(round,SAMPLE_GRID.point(69));sx,sy=map(round,SAMPLE_GRID.point(88));radius=30
        image.paste(initial.crop((x-radius,y-radius-18,x+radius,y+radius+8)),(x-radius,y-radius-18))
        image.paste(initial.crop((sx-radius,sy-radius,sx+radius,sy+radius)),(x-radius,y-radius))
        draw=ImageDraw.Draw(image)
        for index,color in ((54,(255,25,25)),(25,(0,255,0))):
            x,y=SAMPLE_GRID.point(index);radius=SAMPLE_GRID.dx*.45
            draw.ellipse((x-radius,y-radius,x+radius,y+radius),outline=color,width=3)
        obs=self.reader.read(image,SAMPLE_GRID)
        before=self.initial.apply(Move.parse("h0g2"))
        after=before.apply(Move.parse("h7e7"))
        self.assertEqual(after.board,obs.board)
        self.assertEqual(Move.parse("h7e7"),before.transition(obs.board))
        self.assertFalse(obs.issues,obs.issues)
        self.assertFalse(obs.lifted,obs.lifted)

    def test_reported_desktop_calibration_and_appearance(self):
        path = ROOT/"assets/samples/user-diagnostic.jpg"
        if not path.exists():
            self.skipTest("user diagnostic image is private")
        image = Image.open(path).convert('RGB').resize((616,674),Image.Resampling.LANCZOS)
        reported = Grid(35.0704,43.1972,580.4225,639.2535)
        corrected = refine_grid(image,reported)
        crop = corrected.bbox()
        obs = self.reader.read(image.crop(crop),corrected.local(crop[:2]))
        self.assertEqual(self.initial.board,obs.board)
        self.assertFalse(obs.issues,obs.issues)
        self.assertFalse(obs.lifted,obs.lifted)


if __name__ == "__main__":
    unittest.main()
