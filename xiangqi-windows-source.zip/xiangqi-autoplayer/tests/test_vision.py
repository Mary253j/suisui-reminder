from io import BytesIO
import unittest
from PIL import Image
from xiangqi.model import Position, START_FEN, Move
from xiangqi.vision import ROOT, Recognizer, SAMPLE_GRID, Grid, refine_grid


class VisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reader = Recognizer()
        cls.initial = Position.from_fen(START_FEN)

    def read(self, name, grid=SAMPLE_GRID):
        return self.reader.read(Image.open(ROOT/f"assets/samples/{name}.jpg"), grid)

    def test_provided_three_screenshots(self):
        initial = self.read("initial")
        selected = self.read("selected")
        moved = self.read("moved")
        self.assertEqual(self.initial.board, initial.board)
        self.assertEqual(self.initial.board, selected.board)
        p = self.initial.apply(Move.parse("h0g2")).apply(Move.parse("h7e7"))
        self.assertEqual(p.board, moved.board)
        self.assertFalse(initial.issues+selected.issues+moved.issues)
        self.assertFalse(initial.lifted)
        self.assertEqual((70,), selected.lifted)

    def test_resize_jpeg_and_translated_crop(self):
        image = Image.open(ROOT/"assets/samples/initial.jpg")
        for factor in (.65, 1.5):
            with self.subTest(factor=factor):
                scaled = image.resize((round(image.width*factor), round(image.height*factor)))
                buf = BytesIO()
                scaled.save(buf, format="JPEG", quality=70)
                buf.seek(0)
                grid = Grid(*(v*factor for v in (40,365,544,912)))
                obs = self.reader.read(Image.open(buf), grid)
                self.assertEqual(self.initial.board, obs.board)
                self.assertFalse(obs.issues, obs.issues)
        box = SAMPLE_GRID.bbox()
        obs = self.reader.read(image.crop(box), SAMPLE_GRID.local(box[:2]))
        self.assertEqual(self.initial.board, obs.board)
        self.assertFalse(obs.issues)

    def test_reversed_view(self):
        # A flipped *layout*, as games render it: glyphs remain upright.
        image = Image.open(ROOT/"assets/samples/initial.jpg")
        reversed_grid = Grid(40,365,544,912,False)
        flipped = image.copy()
        for i, p in enumerate(self.initial.board):
            if p == ".":
                continue
            x,y = SAMPLE_GRID.point(i)
            target_x, target_y = reversed_grid.point(i)
            patch = image.crop((round(x-29),round(y-31),round(x+29),round(y+29)))
            flipped.paste(patch,(round(target_x-29),round(target_y-31)))
        obs = self.reader.read(flipped, reversed_grid)
        self.assertEqual(self.initial.board,obs.board)
        self.assertFalse(obs.issues, obs.issues)

    def test_invalid_calibration(self):
        with self.assertRaises(ValueError):
            Grid(500,900,40,365).validate()

    def test_reported_desktop_calibration_and_appearance(self):
        path = ROOT/"assets/samples/user-diagnostic.jpg"
        if not path.exists():
            self.skipTest("user diagnostic image is private")
        image = Image.open(path).convert('RGB').resize((616,674),Image.Resampling.LANCZOS)
        reported = Grid(35.0704,43.1972,580.4225,639.2535)
        corrected = refine_grid(image,reported)
        crop = corrected.bbox()
        obs = self.reader.read(image.crop(crop),corrected.local(crop[:2]))
        self.assertEqual(self.initial.board,obs.board)
        self.assertFalse(obs.issues,obs.issues)
        self.assertFalse(obs.lifted,obs.lifted)


if __name__ == "__main__":
    unittest.main()
