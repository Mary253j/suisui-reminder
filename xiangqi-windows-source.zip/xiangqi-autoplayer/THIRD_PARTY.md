# 第三方组件

- **Pikafish**：通过外部进程 UCI 通信调用，Python 源码包不附带二进制；Windows 便携 EXE 包内置已校验的官方 Windows x64 引擎、NNUE、许可证及对应源码。项目与源码：<https://github.com/official-pikafish/Pikafish>；许可证为 GNU GPL v3。下载脚本固定使用官方 2026-09-06 发布版及官方 API 返回的 SHA-256。若重新分发引擎，请遵守引擎发行包与源码的许可证要求。
- **NumPy**：BSD 3-Clause，<https://numpy.org/>。
- **Pillow**：HPND，<https://python-pillow.github.io/>。
- **py7zr**：仅下载脚本解压时使用，LGPL-2.1-or-later，<https://github.com/miurahr/py7zr>。
- **PyInstaller**：仅 Windows 打包时使用，GPL-2.0-or-later with bootloader exception，<https://pyinstaller.org/>。
- 参考图片由用户提供，仅作为该用户项目的识别模板与回归样例。
