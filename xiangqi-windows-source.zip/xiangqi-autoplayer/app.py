"""Desktop entry point. CLI recognition does not require a display or engine."""
import argparse
import json
import sys
from pathlib import Path
from PIL import Image
from xiangqi.device import enable_dpi_awareness
from xiangqi.model import Position
from xiangqi.vision import Recognizer, Grid, SAMPLE_GRID, annotate


def main():
    parser = argparse.ArgumentParser(description="皮卡鱼投屏自动象棋")
    parser.add_argument("--recognize", type=Path, help="仅识别图片，不点击")
    parser.add_argument("--grid", type=float, nargs=4, metavar=("X0", "Y0", "X8", "Y9"), help="左上、右下交叉点")
    parser.add_argument("--red-top", action="store_true")
    parser.add_argument("--output", type=Path, help="保存识别标记图")
    parser.add_argument("--smoke-test", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.recognize:
        grid = Grid(*(args.grid or (SAMPLE_GRID.x0, SAMPLE_GRID.y0, SAMPLE_GRID.x8, SAMPLE_GRID.y9)), red_bottom=not args.red_top)
        image = Image.open(args.recognize).convert("RGB")
        obs = Recognizer().read(image, grid)
        print(json.dumps({"fen_red_to_move": Position(obs.board).fen(), "issues": obs.issues,
                          "lifted": obs.lifted, "min_piece_score": min(s for s,p in zip(obs.scores,obs.board) if p != ".") if any(p != "." for p in obs.board) else None}, ensure_ascii=False, indent=2))
        if args.output:
            annotate(image, grid, obs).save(args.output)
        return 1 if obs.issues else 0
    enable_dpi_awareness()
    from xiangqi.gui import App
    if args.smoke_test:
        # Exercise the actual frozen app, its bundled templates and its engine.
        # This captures a frame but never sends mouse or touch input.
        import traceback
        app = None
        try:
            from xiangqi.device import Desktop
            from xiangqi.engine import Pikafish
            from xiangqi.model import START_FEN, Move
            app = App()
            app.update()
            image, origin = Desktop().full()
            if image.width <= 0 or image.height <= 0:
                raise RuntimeError("Desktop capture is empty")
            with Pikafish(app.engine.get(), threads=2, hash_mb=64) as engine:
                move = engine.bestmove(START_FEN, [], 200)
                if Move.parse(move) not in Position.from_fen(START_FEN).legal_moves():
                    raise RuntimeError("Bundled engine returned an illegal move")
                result = {"ok": True, "title": app.title(), "engine": engine.name,
                          "engine_path": app.engine.get(), "move": move,
                          "screen_size": image.size, "screen_origin": origin}
            args.smoke_test.write_text(json.dumps(result, ensure_ascii=False, indent=2), "utf-8")
            return 0
        except Exception:
            args.smoke_test.write_text(json.dumps({"ok": False, "error": traceback.format_exc()}), "utf-8")
            return 1
        finally:
            if app is not None:
                app.destroy()
    App().mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
