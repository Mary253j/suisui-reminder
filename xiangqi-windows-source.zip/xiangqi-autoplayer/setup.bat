@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto check
echo Creating local Python environment...
py -3 -m venv .venv
if not errorlevel 1 goto check
python -m venv .venv
if errorlevel 1 goto missing
:check
".venv\Scripts\python.exe" -c "import sys; assert sys.version_info >= (3,10), 'Python 3.10 or newer is required'"
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -c "import numpy; from PIL import Image, ImageTk" >nul 2>nul
if not errorlevel 1 exit /b 0
echo Installing required packages. Network timeout is 20 seconds per request.
".venv\Scripts\python.exe" -m pip install --timeout 20 --retries 1 -r requirements.txt
if errorlevel 1 goto fail
exit /b 0
:missing
echo Install Python 3.11 or 3.12 from https://www.python.org/downloads/windows/
echo Enable "Add python.exe to PATH", then run start.bat again.
exit /b 1
:fail
echo Setup failed. Please read the error above and README.md.
exit /b 1
