from __future__ import annotations

from collections import deque
from pathlib import Path
from queue import Queue, Empty
import os
import subprocess
import threading
import time


class EngineError(RuntimeError):
    pass


class Pikafish:
    """A single-owner UCI session; reader thread prevents pipe deadlocks."""

    def __init__(self, executable: str | Path | list[str], threads: int = 2,
                 hash_mb: int = 128, eval_file: str = "", cancel=None):
        self.cancel = cancel
        self.lines = Queue()
        self.tail = deque(maxlen=12)
        self.name = "Pikafish"
        self.options = set()
        if isinstance(executable, list):
            command, cwd = executable, None
        else:
            path = Path(executable).expanduser().resolve()
            if not path.is_file():
                raise EngineError("找不到皮卡鱼程序，请选择解压后的可执行文件")
            command, cwd = [str(path)], str(path.parent)
        try:
            self.process = subprocess.Popen(command, cwd=cwd, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                encoding="utf-8", errors="replace", bufsize=1,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        except OSError as exc:
            raise EngineError(f"无法启动引擎: {exc}") from exc
        threading.Thread(target=self._reader, daemon=True).start()
        try:
            self.send("uci")
            self._until("uciok", 20)
            for name, value in (("Threads", threads), ("Hash", hash_mb), ("EvalFile", eval_file)):
                if value != "" and name in self.options:
                    self.send(f"setoption name {name} value {value}")
            self.send("ucinewgame")
            self.send("isready")
            self._until("readyok", 30)
        except BaseException:
            self.close()
            raise

    def _reader(self):
        try:
            for line in self.process.stdout:
                self.lines.put(line.strip())
        finally:
            self.lines.put(None)

    def send(self, command: str):
        if "\n" in command or "\r" in command:
            raise EngineError("UCI 命令包含换行")
        try:
            self.process.stdin.write(command+"\n")
            self.process.stdin.flush()
        except (OSError, ValueError) as exc:
            raise EngineError("引擎已退出。请检查 CPU 兼容性及 NNUE 文件。") from exc

    def _until(self, prefix: str, timeout: float, info=None):
        deadline = time.monotonic()+timeout
        while time.monotonic() < deadline:
            if self.cancel is not None and self.cancel.is_set():
                try:
                    self.send("stop")
                except EngineError:
                    pass
                raise InterruptedError("已停止")
            try:
                line = self.lines.get(timeout=.05)
            except Empty:
                continue
            if line is None:
                raise EngineError("引擎意外退出: "+" | ".join(self.tail))
            self.tail.append(line)
            if "CRITICAL ERROR" in line or "ERROR:" in line:
                raise EngineError(line)
            if line.startswith("id name "):
                self.name = line[8:]
            if line.startswith("option name "):
                self.options.add(line[12:].split(" type ")[0])
            if info and line.startswith("info depth "):
                info(line)
            if line.startswith(prefix):
                return line
        raise EngineError(f"等待引擎 {prefix} 超时: "+" | ".join(self.tail))

    def bestmove(self, initial_fen: str, moves: list[str], movetime_ms: int = 1500, info=None):
        # Keep the full game history so Pikafish can reason about repetition.
        self.send("position fen "+initial_fen+(" moves "+" ".join(moves) if moves else ""))
        self.send(f"go movetime {int(movetime_ms)}")
        line = self._until("bestmove ", movetime_ms/1000+15, info)
        move = line.split()[1]
        return None if move in ("(none)", "0000") else move

    def close(self):
        if not hasattr(self, "process"):
            return
        if self.process.poll() is None:
            try:
                self.send("stop")
                self.send("quit")
                self.process.wait(timeout=1)
            except (OSError, subprocess.TimeoutExpired, EngineError):
                self.process.kill()
                self.process.wait(timeout=2)
        for pipe in (self.process.stdin, self.process.stdout):
            if pipe:
                try:
                    pipe.close()
                except OSError:
                    pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
