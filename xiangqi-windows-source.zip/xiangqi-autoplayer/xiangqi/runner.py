from __future__ import annotations

from dataclasses import dataclass, field
import time
from .device import StopToken
from .engine import Pikafish
from .model import Move, Position, color
from .vision import Grid, Recognizer, Observation, unresolved_issues


@dataclass
class Settings:
    grid: Grid
    engine_path: str
    our_side: str = "w"
    initial_side: str = "w"
    movetime_ms: int = 1500
    threads: int = 2
    hash_mb: int = 128
    poll_seconds: float = .15
    click_gap: float = .2
    verify_timeout: float = 12
    eval_file: str = ""
    confirmed_cells: dict[int, str] = field(default_factory=dict)


class AutoPlayer:
    def __init__(self, settings: Settings, device, recognizer: Recognizer,
                 token: StopToken | None = None, log=None, update=None,
                 engine_factory=Pikafish, on_position=None):
        self.settings, self.device, self.recognizer = settings, device, recognizer
        self.token = token or StopToken()
        self.log = log or (lambda msg: None)
        self.update = update or (lambda *args: None)
        self.engine_factory = engine_factory
        self.on_position = on_position or (lambda p: None)
        self.position = None
        self.history = []
        self.initial_fen = ""
        self.confirmed_cells = dict(settings.confirmed_cells)

    def _scan(self):
        self.token.check()
        image, local = self.device.frame(self.settings.grid)
        obs = self.recognizer.read(image, local)
        self.token.check()
        self.update(image, local, obs)
        return obs

    def _stable(self, timeout=10, allow_lifted=False):
        deadline = time.monotonic()+timeout
        previous, count, last = None, 0, None
        while time.monotonic() < deadline:
            obs = self._scan()
            last = obs
            valid = not unresolved_issues(obs,self.confirmed_cells) and (allow_lifted or not obs.lifted)
            if valid:
                key = (obs.board, obs.lifted)
                count = count+1 if key == previous else 1
                previous = key
                if count >= 2:
                    return obs
            else:
                previous, count = None, 0
            self.token.wait(self.settings.poll_seconds)
        pending = unresolved_issues(last,self.confirmed_cells) if last else ()
        detail = "; ".join(pending[:4]) if pending else "动画未结束、棋子被选中或棋盘被遮挡"
        raise RuntimeError("未获得稳定棋盘: "+detail)

    def _accept(self, move: Move):
        self.position = self.position.apply(move)
        # A confirmed square is no longer trusted once its piece moves or is captured.
        self.confirmed_cells.pop(move.src,None)
        self.confirmed_cells.pop(move.dst,None)
        self.history.append(move.uci())
        self.on_position(self.position)
        self.log("已确认走棋 "+move.uci())

    def _execute(self, move: Move):
        expected = self.position.apply(move)
        fresh = self._stable()
        if fresh.board != self.position.board:
            raise RuntimeError("计算期间棋盘发生变化；已暂停，请重新预览")
        self.token.check()
        self.log("选择棋子 "+move.uci()[:2])
        self.device.tap(self.settings.grid.point(move.src), self.token)
        self.token.wait(self.settings.click_gap)
        # A selected piece rises, but must still normalize to the same board.
        selected = self._scan()
        if unresolved_issues(selected,self.confirmed_cells) or selected.board != self.position.board:
            raise RuntimeError("选择棋子后画面异常；已停止，请手动取消选择并重新预览")
        if set(selected.lifted) != {move.src}:
            raise RuntimeError("未检测到计划棋子被选中抬高；已停止，请检查投屏点击是否生效")
        self.token.check()
        self.device.tap(self.settings.grid.point(move.dst), self.token)
        self.log("已点击落点，正在核对实际局面")
        deadline = time.monotonic()+self.settings.verify_timeout
        previous, count = None, 0
        while time.monotonic() < deadline:
            obs = self._scan()
            if not unresolved_issues(obs,self.confirmed_cells) and not obs.lifted:
                count = count+1 if obs.board == previous else 1
                previous = obs.board
                if count >= 2:
                    reply = None if obs.board == expected.board else expected.transition(obs.board)
                    if obs.board == expected.board or reply is not None:
                        self._accept(move)
                        if reply:
                            self._accept(reply)
                        return
            else:
                previous, count = None, 0
            self.token.wait(self.settings.poll_seconds)
        raise RuntimeError("落子未通过核对，可能投屏不支持点击或仍停在选中状态；已停止，不会重复点击")

    def run(self, approved_board: tuple[str, ...], analysis_only=False):
        cfg = self.settings
        cfg.grid.validate()
        obs = self._stable()
        if obs.board != approved_board:
            raise RuntimeError("局面已与预览不同，请重新识别预览后开始")
        self.position = Position(obs.board, cfg.initial_side)
        errors = self.position.problems()
        if errors:
            raise RuntimeError("; ".join(errors))
        self.initial_fen = self.position.fen()
        self.on_position(self.position)
        self.log("稳定棋盘已确认；"+("红方" if self.position.side == "w" else "黑方")+"行棋")
        with self.engine_factory(cfg.engine_path, threads=cfg.threads, hash_mb=cfg.hash_mb,
                                 eval_file=cfg.eval_file, cancel=self.token) as engine:
            self.log("已连接引擎: "+engine.name)
            while True:
                self.token.check()
                if analysis_only or self.position.side == cfg.our_side:
                    legal = set(self.position.legal_moves())
                    if not legal:
                        self.log("当前方已无合法走法，停止")
                        return
                    self.log("引擎计算中…")
                    text = engine.bestmove(self.initial_fen, self.history, cfg.movetime_ms)
                    if text is None:
                        raise RuntimeError("引擎未给出走法，但当前仍有合法走法")
                    move = Move.parse(text)
                    if move not in legal:
                        raise RuntimeError("引擎给出了非法走法，停止: "+text)
                    self.log("建议走法: "+text)
                    if analysis_only:
                        return
                    self._execute(move)
                else:
                    self.log("等待对方走棋…")
                    while True:
                        obs = self._stable(timeout=12)
                        if obs.board == self.position.board:
                            self.token.wait(cfg.poll_seconds)
                            continue
                        move = self.position.transition(obs.board)
                        if move is None:
                            raise RuntimeError("检测到无法用一步合法走棋解释的变化；请重新预览，确认行棋方")
                        self._accept(move)
                        break
