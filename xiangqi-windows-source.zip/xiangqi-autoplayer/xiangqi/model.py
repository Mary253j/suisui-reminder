from __future__ import annotations

from dataclasses import dataclass
from collections import Counter
import re

START_FEN = "rnbakabnr/9/1c5c1/p1p1p1p1p/9/9/P1P1P1P1P/1C5C1/9/RNBAKABNR w - - 0 1"
NAMES = dict(zip("KABNRCPkabnrcp", "帅仕相马车炮兵将士象马车炮卒"))


def color(piece: str) -> str:
    return "w" if piece.isupper() else "b"


def other(side: str) -> str:
    return "b" if side == "w" else "w"


@dataclass(frozen=True)
class Move:
    src: int
    dst: int

    @classmethod
    def parse(cls, text: str) -> "Move":
        if not re.fullmatch(r"[a-i][0-9][a-i][0-9]", text):
            raise ValueError(f"无效的 UCI 走法: {text}")
        a, b, c, d = text
        return cls((9-int(b))*9+ord(a)-97, (9-int(d))*9+ord(c)-97)

    def uci(self) -> str:
        def sq(i: int) -> str:
            return chr(97+i % 9) + str(9-i//9)
        return sq(self.src) + sq(self.dst)


@dataclass(frozen=True)
class Position:
    board: tuple[str, ...]
    side: str = "w"
    halfmove: int = 0
    fullmove: int = 1

    def __post_init__(self):
        if len(self.board) != 90 or self.side not in ("w", "b"):
            raise ValueError("棋盘必须为 90 格，行棋方必须为 w/b")
        if any(p not in ".KABNRCPkabnrcp" for p in self.board):
            raise ValueError("未知棋子")

    @classmethod
    def from_fen(cls, fen: str) -> "Position":
        fields = fen.split()
        if len(fields) < 2:
            raise ValueError("FEN 缺少行棋方")
        board = []
        rows = fields[0].replace("h", "n").replace("H", "N").replace("e", "b").replace("E", "B").split("/")
        if len(rows) != 10:
            raise ValueError("FEN 必须为十行")
        for row in rows:
            cells = []
            for p in row:
                cells.extend(["."]*int(p) if p in "123456789" else [p])
            if len(cells) != 9:
                raise ValueError("FEN 每行必须为九列")
            board.extend(cells)
        return cls(tuple(board), fields[1], int(fields[4]) if len(fields)>4 else 0,
                   int(fields[5]) if len(fields)>5 else 1)

    def fen(self) -> str:
        rows = []
        for r in range(10):
            row, empty = "", 0
            for p in self.board[r*9:(r+1)*9]:
                if p == ".":
                    empty += 1
                else:
                    row += (str(empty) if empty else "") + p
                    empty = 0
            rows.append(row + (str(empty) if empty else ""))
        return f"{'/'.join(rows)} {self.side} - - {self.halfmove} {self.fullmove}"

    def apply(self, move: Move) -> "Position":
        b = list(self.board)
        moving, taken = b[move.src], b[move.dst]
        b[move.dst], b[move.src] = moving, "."
        return Position(tuple(b), other(self.side),
                        0 if taken != "." or moving.lower() == "p" else self.halfmove+1,
                        self.fullmove+(self.side == "b"))

    def problems(self) -> list[str]:
        errors = []
        counts = Counter(self.board)
        for side in ("w", "b"):
            for p, limit in zip("kabnrcp", (1, 2, 2, 2, 2, 2, 5)):
                symbol = p.upper() if side == "w" else p
                if counts[symbol] > limit or (p == "k" and counts[symbol] != 1):
                    errors.append(f"{NAMES[symbol]}数量异常: {counts[symbol]}")
        for i, p in enumerate(self.board):
            if p == ".":
                continue
            r, c = divmod(i, 9)
            rr = 9-r if p.isupper() else r
            if p.lower() == "k" and not (0 <= rr <= 2 and 3 <= c <= 5):
                errors.append("将帅不在九宫内")
            if p.lower() == "a" and (rr, c) not in {(0, 3),(0, 5),(1, 4),(2, 3),(2, 5)}:
                errors.append("士仕位置异常")
            if p.lower() == "b" and (rr, c) not in {(0, 2),(0, 6),(2, 0),(2, 4),(2, 8),(4, 2),(4, 6)}:
                errors.append("象相位置异常")
            if p.lower() == "p" and (rr < 3 or (rr <= 4 and c % 2)):
                errors.append("兵卒位置异常")
        if not errors and self.in_check(other(self.side)):
            errors.append("非行棋方仍被将军，请检查当前轮到谁走及识别结果")
        return list(dict.fromkeys(errors))

    def _pseudo(self, i: int, attacks: bool = False):
        p = self.board[i]
        if p == ".":
            return
        side, kind = color(p), p.lower()
        r, c = divmod(i, 9)
        for rr in range(10):
            for cc in range(9):
                j = rr*9+cc
                target = self.board[j]
                if i == j or (target != "." and color(target) == side):
                    continue
                dr, dc = rr-r, cc-c
                ar, ac = abs(dr), abs(dc)
                valid = False
                if kind in ("r", "c") and (dr == 0 or dc == 0):
                    step = (9 if dr > 0 else -9) if dr else (1 if dc > 0 else -1)
                    between = sum(self.board[k] != "." for k in range(i+step, j, step))
                    valid = between == (1 if kind == "c" and target != "." else 0)
                elif kind == "n" and sorted((ar, ac)) == [1, 2]:
                    leg = i + (9*(1 if dr>0 else -1) if ar == 2 else (1 if dc>0 else -1))
                    valid = self.board[leg] == "."
                elif kind == "b" and ar == ac == 2:
                    valid = self.board[(r+dr//2)*9+c+dc//2] == "." and (rr >= 5 if side == "w" else rr <= 4)
                elif kind in ("a", "k"):
                    palace = 3 <= cc <= 5 and (7 <= rr <= 9 if side == "w" else 0 <= rr <= 2)
                    valid = palace and ((ar == ac == 1) if kind == "a" else ar+ac == 1)
                    if kind == "k" and dc == 0 and target.lower() == "k":
                        step = 9 if dr > 0 else -9
                        valid = all(self.board[k] == "." for k in range(i+step, j, step))
                elif kind == "p":
                    valid = (dr == (-1 if side == "w" else 1) and dc == 0) or (
                        dr == 0 and ac == 1 and (r <= 4 if side == "w" else r >= 5))
                if valid:
                    yield Move(i, j)

    def in_check(self, side: str) -> bool:
        king = "K" if side == "w" else "k"
        if king not in self.board:
            return True
        k = self.board.index(king)
        for i, p in enumerate(self.board):
            if p != "." and color(p) != side and any(m.dst == k for m in self._pseudo(i, True)):
                return True
        return False

    def legal_moves(self):
        for i, p in enumerate(self.board):
            if p != "." and color(p) == self.side:
                for move in self._pseudo(i):
                    if not self.apply(move).in_check(self.side):
                        yield move

    def transition(self, board: tuple[str, ...]) -> Move | None:
        changed = [i for i, (a, b) in enumerate(zip(self.board, board)) if a != b]
        if len(changed) != 2:
            return None
        src = next((i for i in changed if self.board[i] != "." and board[i] == "." and color(self.board[i]) == self.side), None)
        if src is None:
            return None
        dst = next(i for i in changed if i != src)
        move = Move(src, dst)
        if self.board[src] != board[dst]:
            return None
        return move if move in self.legal_moves() else None
