from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class Grid:
    x0: float
    y0: float
    x8: float
    y9: float
    red_bottom: bool = True

    @property
    def dx(self):
        return (self.x8-self.x0)/8

    @property
    def dy(self):
        return (self.y9-self.y0)/9

    def point(self, index: int):
        r, c = divmod(index, 9)
        if not self.red_bottom:
            r, c = 9-r, 8-c
        return self.x0+c*self.dx, self.y0+r*self.dy

    def bbox(self):
        return (round(self.x0-self.dx*.52), round(self.y0-self.dy*.65),
                round(self.x8+self.dx*.52), round(self.y9+self.dy*.52))

    def local(self, origin):
        x, y = origin
        return Grid(self.x0-x, self.y0-y, self.x8-x, self.y9-y, self.red_bottom)

    def validate(self):
        if min(self.dx, self.dy) < 22:
            raise ValueError("棋盘过小或两点顺序错误，请放大投屏并重新校准")
        if not .7 < self.dx/self.dy < 1.35:
            raise ValueError("两点应是棋盘左上、右下的交叉点（九列十行）")


SAMPLE_GRID = Grid(40, 365, 544, 912)


def glyph(image: Image.Image, grid: Grid, index: int, shift: float = 0, scale: float = 1):
    x, y = grid.point(index)
    # The painted character is slightly above the board intersection.
    y += (shift-.075)*grid.dy
    rx, ry = .315*grid.dx*scale, .315*grid.dy*scale
    rgb = image if image.mode == "RGB" else image.convert("RGB")
    patch = rgb.transform((32, 32), Image.Transform.EXTENT,
                                          (x-rx, y-ry, x+rx, y+ry), Image.Resampling.BILINEAR)
    a = np.asarray(patch).astype(np.float32)
    r, g, b = a[:,:,0], a[:,:,1], a[:,:,2]
    green = (g > r*1.12) & (g > b*1.12)
    # Vivid red UI rings are much brighter and more saturated than the dark
    # red piece characters. Suppress those pixels in both color channels.
    red_marker = (r > 175) & (g < 110) & (r > g*1.8) & (r > b*1.8)
    red = np.clip((r-g-27)/40, 0, 1) * np.clip((160-g)/50, 0, 1)
    black = np.clip((125-np.maximum(r, g))/50, 0, 1)
    # Outside the character region, rims and selection rings are irrelevant.
    yy, xx = np.ogrid[:32, :32]
    circle = (xx-15.5)**2+(yy-15.5)**2 < 15.5**2
    red[green | red_marker | ~circle] = 0
    black[green | red_marker | ~circle] = 0
    return np.stack((red, black)).reshape(2, -1)


def refine_grid(image: Image.Image, grid: Grid) -> Grid:
    """Gently fit manually selected corners to the visible chessboard lines.

    Input and result use coordinates in the captured image. The search stays
    within one quarter of a square; it cannot jump to another board.
    """
    grid.validate()
    pixels = np.asarray(image.convert("RGB"), dtype=np.float32).mean(axis=2)
    height, width = pixels.shape
    pad = max(1, round(min(grid.dx, grid.dy)*.035))
    if width <= pad*2 or height <= pad*2:
        return grid
    ya, yb = max(0, round(grid.y0+.2*grid.dy)), min(height, round(grid.y9-.2*grid.dy))
    xa, xb = max(0, round(grid.x0+.2*grid.dx)), min(width, round(grid.x8-.2*grid.dx))
    if ya >= yb or xa >= xb:
        return grid
    vertical = np.zeros(width, dtype=np.float32)
    horizontal = np.zeros(height, dtype=np.float32)
    vertical[pad:-pad] = np.maximum(0, (pixels[ya:yb,:-2*pad]+pixels[ya:yb,2*pad:])/2-pixels[ya:yb,pad:-pad]).mean(axis=0)
    horizontal[pad:-pad] = np.maximum(0, (pixels[:-2*pad,xa:xb]+pixels[2*pad:,xa:xb])/2-pixels[pad:-pad,xa:xb]).mean(axis=1)
    def fit(profile, start, end, count):
        spacing = (end-start)/(count-1)
        shifts = np.arange(-.26*spacing, .26*spacing+.01, .5)
        axis = np.arange(len(profile))
        best = (-1.0, (start, end))
        for ds in shifts:
            for de in shifts:
                positions = np.linspace(start+ds,end+de,count)[1:-1]
                if positions[0]<0 or positions[-1]>=len(profile)-1:
                    continue
                score = float(np.interp(positions,axis,profile).mean())
                if score>best[0]:
                    best = (score, (start+ds,end+de))
        return best
    vx, x = fit(vertical,grid.x0,grid.x8,9)
    hy, y = fit(horizontal,grid.y0,grid.y9,10)
    if min(vx,hy)<3:
        return grid
    adjusted = Grid(float(x[0]),float(y[0]),float(x[1]),float(y[1]),grid.red_bottom)
    try:
        adjusted.validate()
    except ValueError:
        return grid
    return adjusted


def build_templates(path: Path | None = None):
    from .model import Position, START_FEN
    image = Image.open(ROOT/"assets/samples/initial.jpg")
    board = Position.from_fen(START_FEN).board
    labels, features = [], []
    for i, p in enumerate(board):
        if p != ".":
            labels.append(p)
            features.append(glyph(image, SAMPLE_GRID, i)[0 if p.isupper() else 1])
    np.savez_compressed(path or ROOT/"assets/templates.npz", labels=np.array(labels), features=np.array(features))


@dataclass
class Observation:
    board: tuple[str, ...]
    scores: tuple[float, ...]
    issues: tuple[str, ...]
    lifted: tuple[int, ...]


class Recognizer:
    def __init__(self, templates: Path | None = None, threshold: float = .64, margin: float = .065):
        data = np.load(templates or ROOT/"assets/templates.npz", allow_pickle=False)
        self.labels = data["labels"].tolist()
        self.features = data["features"].astype(np.float32)
        self.sums = np.square(self.features).sum(axis=1)
        self.threshold, self.margin = threshold, margin

    def read(self, image: Image.Image, grid: Grid) -> Observation:
        board, scores, issues, lifted = [], [], [], []
        shifts = (0, -.08, .08, -.16, -.24, -.32)
        for index in range(90):
            candidates = np.stack([glyph(image, grid, index, shift, scale)
                                   for scale in (1.0, .93, 1.07) for shift in shifts])
            channels = np.array([0 if p.isupper() else 1 for p in self.labels])
            values = candidates[:, channels, :]
            numerator = 2*np.einsum("ctn,tn->ct", values, self.features)
            denominator = np.square(values).sum(axis=2)+self.sums[None, :]+1e-6
            similarities = numerator/denominator
            by_class = {}
            best_shift = {}
            for j, label in enumerate(self.labels):
                n = int(similarities[:,j].argmax())
                s = float(similarities[n,j])
                if s > by_class.get(label, -1):
                    by_class[label] = s
                    best_shift[label] = shifts[n % len(shifts)]
            ranked = sorted(by_class.items(), key=lambda t: t[1], reverse=True)
            (p, score), (_, second) = ranked[:2]
            # Empty intersections have lines or dots but no full character.
            if score < .48:
                board.append(".")
                scores.append(1-score)
                continue
            board.append(p)
            scores.append(score)
            if score < self.threshold or score-second < self.margin:
                issues.append(f"{chr(97+index%9)}{9-index//9}: {p} 匹配 {score:.2f}，差值 {score-second:.2f}")
            if best_shift[p] <= -.16:
                lifted.append(index)
        return Observation(tuple(board), tuple(scores), tuple(issues), tuple(lifted))


def annotate(image: Image.Image, grid: Grid, obs: Observation) -> Image.Image:
    out = image.convert("RGB").copy()
    draw = ImageDraw.Draw(out)
    for i, p in enumerate(obs.board):
        x, y = grid.point(i)
        s = obs.scores[i]
        col = "#00aaee" if p == "." else ("#e91e63" if p.isupper() else "#2266ff")
        draw.ellipse((x-3, y-3, x+3, y+3), outline=col, width=2)
        if p != ".":
            draw.text((x-grid.dx*.35, y-grid.dy*.5), f"{p} {s:.2f}", fill=col, stroke_width=1, stroke_fill="white")
    return out
