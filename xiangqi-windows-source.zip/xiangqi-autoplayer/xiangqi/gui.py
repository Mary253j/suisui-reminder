from __future__ import annotations

from dataclasses import asdict, replace
from datetime import datetime
from pathlib import Path
from queue import Queue, Empty
import json
import os
import sys
import threading
import traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk

from .device import Android, Desktop, StopToken
from .model import Position, NAMES
from .runner import AutoPlayer, Settings
from .vision import ROOT, Grid, Recognizer, annotate, refine_grid

DATA_ROOT = Path(sys.executable).parent if getattr(sys, "frozen", False) else ROOT


class Calibration(tk.Toplevel):
    def __init__(self, master, image, origin, red_bottom, complete):
        super().__init__(master)
        self.title("校准：依次点击左上、右下交叉点")
        self.origin, self.red_bottom, self.complete = origin, red_bottom, complete
        self.points = []
        self.scale = min(1, (self.winfo_screenwidth()-100)/image.width,
                         (self.winfo_screenheight()-180)/image.height)
        self.photo = ImageTk.PhotoImage(image.resize((round(image.width*self.scale), round(image.height*self.scale))))
        ttk.Label(self, text="先点左上角交叉点（左车所在格），再点右下角交叉点。点棋盘线交点，不点外框。Esc 取消。",
                  padding=10).pack()
        self.canvas = tk.Canvas(self, width=self.photo.width(), height=self.photo.height(), cursor="crosshair", highlightthickness=0)
        self.canvas.pack()
        self.canvas.create_image(0, 0, anchor="nw", image=self.photo)
        self.canvas.bind("<Button-1>", self._click)
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()

    def _click(self, event):
        x, y = event.x, event.y
        self.points.append((x/self.scale+self.origin[0], y/self.scale+self.origin[1]))
        self.canvas.create_line(x-12, y, x+12, y, fill="#00ffff", width=2)
        self.canvas.create_line(x, y-12, x, y+12, fill="#00ffff", width=2)
        if len(self.points) == 2:
            a, b = self.points
            grid = Grid(*a, *b, self.red_bottom)
            try:
                grid.validate()
            except ValueError as exc:
                messagebox.showerror("校准失败", str(exc), parent=self)
                self.destroy()
                return
            self.complete(grid)
            self.destroy()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("皮卡鱼投屏自动象棋")
        self.geometry(f"{min(1120, self.winfo_screenwidth()-40)}x{min(850, self.winfo_screenheight()-70)}")
        self.minsize(980, 650)
        self.events, self.token = Queue(), None
        self.busy, self.closing = False, False
        self.grid, self.approved, self.latest = None, None, None
        self.photo = None
        self.recognizer = Recognizer()
        self.config_path = DATA_ROOT/"config.json"
        self.logs_dir = DATA_ROOT/"logs"
        self.logs_dir.mkdir(exist_ok=True)
        self.log_file = self.logs_dir/(datetime.now().strftime("%Y%m%d-%H%M%S")+".log")
        self.mode = tk.StringVar(value="电脑投屏（鼠标）")
        self.engine = tk.StringVar()
        self.adb = tk.StringVar(value="adb")
        self.serial = tk.StringVar()
        self.our = tk.StringVar(value="红方")
        self.turn = tk.StringVar(value="红方")
        self.orientation = tk.StringVar(value="红方在下")
        self.think = tk.StringVar(value="1500")
        self.threads = tk.StringVar(value="2")
        self.hash_mb = tk.StringVar(value="128")
        self.state_text = tk.StringVar(value="先选择引擎，再校准棋盘")
        self.grid_text = tk.StringVar(value="尚未校准")
        self.fen = tk.StringVar()
        self._load()
        self._build()
        self.orientation.trace_add("write", self._orientation_changed)
        self.mode.trace_add("write", self._mode_changed)
        self.bind("<Escape>", lambda e: self.stop())
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.after(100, self._pump)
        self._log("就绪。自动开始前请核对识别棋盘，以及“当前轮到”。Windows 按 Esc 可停止。")

    def _build(self):
        style = ttk.Style(self)
        style.configure("TButton", padding=(8, 6))
        style.configure("Title.TLabel", font=("Microsoft YaHei UI", 15, "bold"))
        top = ttk.Frame(self, padding=(16, 10))
        top.pack(fill="x")
        ttk.Label(top, text="皮卡鱼 · 投屏自动象棋", style="Title.TLabel").pack(side="left")
        ttk.Label(top, textvariable=self.state_text).pack(side="right")
        body = ttk.Frame(self, padding=(16, 0, 16, 8))
        body.pack(fill="both", expand=True)
        left = ttk.Frame(body, width=430)
        left.pack(side="left", fill="both", expand=True, padx=(0, 14))
        tabs = ttk.Notebook(left)
        tabs.pack(fill="both", expand=True)
        self.preview = tk.Canvas(tabs, width=420, height=540, bg="#20282a", highlightthickness=0)
        self.diagram = tk.Canvas(tabs, width=420, height=540, bg="#edcf94", highlightthickness=0)
        tabs.add(self.preview, text="截图及识别分数")
        tabs.add(self.diagram, text="识别棋盘（请核对）")
        ttk.Label(left, text="K帅 A仕 B相 N马 R车 C炮 P兵；小写为黑方", padding=(0, 6)).pack()
        ttk.Entry(left, textvariable=self.fen).pack(fill="x")
        ttk.Button(left, text="保存诊断截图及局面", command=self.save_debug).pack(anchor="w", pady=6)
        right = ttk.Frame(body, width=590)
        right.pack(side="right", fill="both")
        right.pack_propagate(False)
        source = ttk.LabelFrame(right, text="1. 画面和控制方式", padding=10)
        source.pack(fill="x", pady=(0, 8))
        self.controls = []
        self._combo(source, "方式", self.mode, ("电脑投屏（鼠标）", "Android ADB（直连）"), 0)
        self._entry(source, "ADB 路径", self.adb, 1, self.choose_adb)
        self._entry(source, "设备序列号", self.serial, 2)
        ttk.Label(source, text="ADB 仅在投屏不能接收鼠标时使用；该模式直接获取手机截图。").grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))
        engine = ttk.LabelFrame(right, text="2. 皮卡鱼引擎", padding=10)
        engine.pack(fill="x", pady=(0, 8))
        self._entry(engine, "引擎程序", self.engine, 0, self.choose_engine)
        params = ttk.Frame(engine)
        params.grid(row=1, column=0, columnspan=3, sticky="w", pady=(8, 0))
        for text, var, width in (("思考毫秒", self.think, 7), ("线程", self.threads, 3), ("Hash MB", self.hash_mb, 5)):
            ttk.Label(params, text=text).pack(side="left", padx=(0, 5))
            entry = ttk.Entry(params, textvariable=var, width=width)
            entry.pack(side="left", padx=(0, 10))
            self.controls.append(entry)
        game = ttk.LabelFrame(right, text="3. 棋盘与行棋方", padding=10)
        game.pack(fill="x", pady=(0, 8))
        self._combo(game, "棋盘方向", self.orientation, ("红方在下", "红方在上"), 0)
        self._combo(game, "程序执棋", self.our, ("红方", "黑方"), 1)
        self._combo(game, "当前轮到", self.turn, ("红方", "黑方"), 2)
        ttk.Label(game, textvariable=self.grid_text).grid(row=3, column=0, columnspan=3, sticky="w", pady=6)
        row = ttk.Frame(game)
        row.grid(row=4, column=0, columnspan=3, sticky="w")
        for label, action in (("校准棋盘", self.calibrate), ("识别预览", self.preview_board)):
            button = ttk.Button(row, text=label, command=action)
            button.pack(side="left", padx=(0, 8))
            self.controls.append(button)
        ttk.Label(game, text="中途接局必须手动选对“当前轮到”。新开一局需要重新预览。").grid(row=5, column=0, columnspan=3, sticky="w", pady=(8, 0))
        actions = ttk.Frame(right)
        actions.pack(fill="x", pady=(0, 8))
        for label, action in (("只计算一步", lambda: self.start(True)), ("自动开始", lambda: self.start(False))):
            button = ttk.Button(actions, text=label, command=action)
            button.pack(side="left", padx=(0, 8))
            self.controls.append(button)
        ttk.Button(actions, text="停止（Esc）", command=self.stop).pack(side="right")
        self.log_view = tk.Text(right, height=10, width=65, wrap="word", state="disabled", font=("Microsoft YaHei UI", 9))
        self.log_view.pack(fill="both", expand=True)
        ttk.Label(self, text="投屏窗口保持位置、大小不变且不被遮挡；自动运行时不要手动落子。选中棋子抬高时，先取消选择再开始。",
                  padding=(16, 0, 16, 10)).pack(anchor="w")

    def _entry(self, parent, label, variable, row, browse=None):
        parent.columnconfigure(1, weight=1)
        ttk.Label(parent, text=label, width=10).grid(row=row, column=0, sticky="w", pady=3)
        entry = ttk.Entry(parent, textvariable=variable, width=39)
        entry.grid(row=row, column=1, sticky="ew", pady=3)
        self.controls.append(entry)
        if browse:
            button = ttk.Button(parent, text="选择", command=browse, width=5)
            button.grid(row=row, column=2, padx=(6, 0))
            self.controls.append(button)

    def _combo(self, parent, label, variable, values, row):
        ttk.Label(parent, text=label, width=10).grid(row=row, column=0, sticky="w", pady=3)
        combo = ttk.Combobox(parent, textvariable=variable, values=values, state="readonly", width=27)
        combo.grid(row=row, column=1, columnspan=2, sticky="w", pady=3)
        self.controls.append(combo)

    def _device(self):
        return Desktop() if self.mode.get().startswith("电脑") else Android(self.adb.get(), self.serial.get())

    def _load(self):
        if not self.config_path.exists():
            candidates = sorted((DATA_ROOT/"engine").rglob("*pikafish*.exe")) if (DATA_ROOT/"engine").exists() else []
            if len(candidates) == 1:
                self.engine.set(str(candidates[0]))
            return
        try:
            data = json.loads(self.config_path.read_text("utf-8"))
            for key in ("mode", "engine", "adb", "serial", "our", "turn", "orientation", "think", "threads", "hash_mb"):
                if key in data:
                    getattr(self, key).set(data[key])
            if data.get("grid"):
                self.grid = Grid(**data["grid"])
                self.grid.validate()
                self.grid_text.set(self._grid_label())
        except (OSError, ValueError, TypeError):
            self.grid = None

    def _save(self):
        data = {key: getattr(self, key).get() for key in
                ("mode", "engine", "adb", "serial", "our", "turn", "orientation", "think", "threads", "hash_mb")}
        data["grid"] = asdict(self.grid) if self.grid else None
        self.config_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")

    def _grid_label(self):
        g = self.grid
        return f"交叉点: ({g.x0:.0f}, {g.y0:.0f}) → ({g.x8:.0f}, {g.y9:.0f})"

    def _orientation_changed(self, *args):
        if self.grid:
            data = asdict(self.grid)
            data["red_bottom"] = self.orientation.get() == "红方在下"
            self.grid = Grid(**data)
        self.approved = None

    def _mode_changed(self, *args):
        self.grid, self.approved = None, None
        self.grid_text.set("控制方式已变更，请重新校准")

    def choose_engine(self):
        path = filedialog.askopenfilename(title="选择 Pikafish 可执行文件", initialdir=DATA_ROOT/"engine")
        if path:
            self.engine.set(path)

    def choose_adb(self):
        path = filedialog.askopenfilename(title="选择 adb.exe")
        if path:
            self.adb.set(path)

    def _set_busy(self, value):
        self.busy = value
        for widget in self.controls:
            widget.configure(state="disabled" if value else ("readonly" if isinstance(widget, ttk.Combobox) else "normal"))

    def _worker(self, action, complete=None, invalidate=False):
        self._set_busy(True)
        def work():
            try:
                result = action()
                if complete:
                    self.events.put(("call", lambda: complete(result)))
            except InterruptedError as exc:
                self.events.put(("log", str(exc)))
            except Exception as exc:
                self.events.put(("error", str(exc)))
                self.events.put(("trace", traceback.format_exc()))
            finally:
                self.events.put(("done", invalidate))
        threading.Thread(target=work, daemon=True).start()

    def calibrate(self):
        if self.busy:
            return
        device = self._device()
        red_bottom = self.orientation.get() == "红方在下"
        self.state_text.set("3 秒后截取屏幕，请露出完整棋盘")
        self.withdraw()
        def capture():
            def complete(result):
                self.deiconify()
                image, origin = result
                Calibration(self, image, origin, red_bottom, self._calibrated)
            self._worker(device.full, complete)
        self.after(3000, capture)

    def _calibrated(self, grid):
        self.grid, self.approved = grid, None
        self.grid_text.set(self._grid_label())
        self.state_text.set("已校准，请识别预览")
        self._save()

    def preview_board(self):
        if self.busy:
            return
        if self.grid is None:
            messagebox.showinfo("需要校准", "先点击“校准棋盘”，标出两个角的交叉点。")
            return
        device, grid = self._device(), self.grid
        def read():
            image, local = device.frame(grid)
            aligned = refine_grid(image, local)
            corrected = Grid(grid.x0+aligned.x0-local.x0, grid.y0+aligned.y0-local.y0,
                             grid.x8+aligned.x8-local.x8, grid.y9+aligned.y9-local.y9, grid.red_bottom)
            if max(abs(a-b) for a,b in zip((grid.x0,grid.y0,grid.x8,grid.y9),
                                             (corrected.x0,corrected.y0,corrected.x8,corrected.y9))) > .5:
                try:
                    adjusted_image, adjusted_local = device.frame(corrected)
                    adjusted_obs = self.recognizer.read(adjusted_image, adjusted_local)
                    original_obs = self.recognizer.read(image, local)
                    if not adjusted_obs.issues and not original_obs.issues and adjusted_obs.board != original_obs.board:
                        original_obs = replace(original_obs, issues=("自动微调前后局面不一致，请重新校准",))
                        return image, local, original_obs, grid
                    if not adjusted_obs.issues:
                        return adjusted_image, adjusted_local, adjusted_obs, corrected
                    if len(adjusted_obs.issues) < len(original_obs.issues):
                        return adjusted_image, adjusted_local, adjusted_obs, corrected
                    return image, local, original_obs, grid
                except RuntimeError:
                    pass
            return image, local, self.recognizer.read(image, local), grid
        def complete(result):
            image, local, obs, corrected = result
            if corrected != self.grid:
                self.grid = corrected
                self.grid_text.set(self._grid_label())
                self._save()
                self._log("已根据棋盘线自动微调校准坐标。")
            self._show(image, local, obs)
            if obs.issues:
                self.approved = None
                self._log("识别不确定: "+"; ".join(obs.issues[:6]))
                self.state_text.set("识别不确定，请重新校准或放大投屏")
            elif obs.lifted:
                self.approved = None
                self._log("检测到棋子抬高。请手动取消选择，再预览。")
                self.state_text.set("请先取消棋子选择")
            else:
                self.approved = obs.board
                self.state_text.set("请核对识别棋盘和当前轮到，然后开始")
                self._log("预览完成。当前轮到谁走无法仅凭静态棋盘确定，请自行选择。")
        self._worker(read, complete)

    def _show(self, image, grid, obs):
        self.latest = (image, grid, obs)
        marked = annotate(image, grid, obs)
        width = max(100, self.preview.winfo_width()-12)
        height = max(100, self.preview.winfo_height()-12)
        marked.thumbnail((width, height))
        self.photo = ImageTk.PhotoImage(marked)
        self.preview.delete("all")
        self.preview.create_image(self.preview.winfo_width()/2, self.preview.winfo_height()/2, image=self.photo)
        self.fen.set(Position(obs.board, "w" if self.turn.get() == "红方" else "b").fen())
        self._draw_board(obs.board, grid.red_bottom)

    def _draw_board(self, board, red_bottom):
        canvas = self.diagram
        canvas.delete("all")
        w, h = max(400, canvas.winfo_width()), max(500, canvas.winfo_height())
        step = min((w-50)/8, (h-60)/9)
        x0, y0 = (w-step*8)/2, (h-step*9)/2
        for r in range(10):
            canvas.create_line(x0, y0+r*step, x0+8*step, y0+r*step, fill="#86633e")
        for c in range(9):
            canvas.create_line(x0+c*step, y0, x0+c*step, y0+9*step, fill="#86633e")
        for i, p in enumerate(board):
            if p == ".":
                continue
            r, c = divmod(i, 9)
            if not red_bottom:
                r, c = 9-r, 8-c
            x, y, rad = x0+c*step, y0+r*step, step*.42
            fill = "#bb2222" if p.isupper() else "#252525"
            canvas.create_oval(x-rad, y-rad, x+rad, y+rad, fill="#ffedc7", outline=fill, width=2)
            canvas.create_text(x, y, text=NAMES[p], fill=fill, font=("Microsoft YaHei UI", round(step*.43), "bold"))

    def start(self, analysis_only):
        if self.busy:
            return
        if self.grid is None or self.approved is None:
            messagebox.showinfo("需要预览", "请先校准并完成一次无异常、无选中棋子的识别预览。")
            return
        try:
            ms, threads, hash_mb = int(self.think.get()), int(self.threads.get()), int(self.hash_mb.get())
            if not (100 <= ms <= 60000 and 1 <= threads <= 128 and 16 <= hash_mb <= 8192):
                raise ValueError("思考时间 100–60000 毫秒，线程 1–128，Hash 16–8192 MB")
            if not Path(self.engine.get()).is_file():
                raise ValueError("请先选择皮卡鱼引擎可执行文件")
            problems = Position(self.approved, "w" if self.turn.get() == "红方" else "b").problems()
            if problems:
                raise ValueError("; ".join(problems))
        except ValueError as exc:
            messagebox.showerror("配置需要调整", str(exc))
            return
        self._save()
        settings = Settings(grid=self.grid, engine_path=self.engine.get(),
            our_side="w" if self.our.get() == "红方" else "b",
            initial_side="w" if self.turn.get() == "红方" else "b",
            movetime_ms=ms, threads=threads, hash_mb=hash_mb)
        device, approved = self._device(), self.approved
        self.token = StopToken()
        player = AutoPlayer(settings, device, self.recognizer, self.token,
            log=lambda s: self.events.put(("log", s)),
            update=lambda *args: self.events.put(("frame", args)),
            on_position=lambda p: self.events.put(("position", p)))
        self.state_text.set("只计算一步" if analysis_only else "自动运行中 · Esc 停止")
        self._worker(lambda: player.run(approved, analysis_only), invalidate=True)

    def stop(self):
        if self.token:
            self.token.set()
            self.state_text.set("正在停止…")

    def save_debug(self):
        if not self.latest:
            return
        image, grid, obs = self.latest
        name = self.logs_dir/(datetime.now().strftime("snapshot-%Y%m%d-%H%M%S"))
        image.save(str(name)+".png")
        Path(str(name)+".json").write_text(json.dumps({"grid": asdict(grid), "board": obs.board,
            "scores": obs.scores, "issues": obs.issues, "lifted": obs.lifted}, ensure_ascii=False, indent=2), "utf-8")
        self._log("已保存诊断: "+str(name))

    def _log(self, message):
        line = datetime.now().strftime("%H:%M:%S ")+message+"\n"
        self.log_view.configure(state="normal")
        self.log_view.insert("end", line)
        self.log_view.see("end")
        self.log_view.configure(state="disabled")
        try:
            with self.log_file.open("a", encoding="utf-8") as stream:
                stream.write(line)
        except OSError:
            pass

    def _pump(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "log":
                    self._log(value)
                elif kind == "trace":
                    with self.log_file.open("a", encoding="utf-8") as stream:
                        stream.write(value)
                elif kind == "frame":
                    self._show(*value)
                elif kind == "position":
                    self.turn.set("红方" if value.side == "w" else "黑方")
                    self.fen.set(value.fen())
                elif kind == "call":
                    value()
                elif kind == "error":
                    self.deiconify()
                    self._log("已暂停: "+value)
                    self.state_text.set("已暂停，请查看日志")
                elif kind == "done":
                    self._set_busy(False)
                    if self.token:
                        self.token.close()
                    self.token = None
                    if value:
                        self.approved = None
                    if self.closing:
                        self.destroy()
                        return
                    if value and "暂停" not in self.state_text.get():
                        self.state_text.set("已停止／任务完成，自动开始前请重新预览")
        except Empty:
            pass
        self.after(100, self._pump)

    def close(self):
        self._save()
        if self.busy:
            self.closing = True
            self.stop()
            self.state_text.set("等待当前操作结束后关闭…")
        else:
            self.destroy()
