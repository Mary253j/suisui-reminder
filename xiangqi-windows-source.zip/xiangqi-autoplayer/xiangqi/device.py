from __future__ import annotations

from io import BytesIO
import os
import subprocess
import threading
from PIL import Image, ImageGrab
from .vision import Grid


def enable_dpi_awareness():
    if os.name == "nt":
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except (AttributeError, OSError):
            ctypes.windll.user32.SetProcessDPIAware()


class StopToken:
    def __init__(self):
        self.event = threading.Event()
        self._watcher_stop = threading.Event()
        if os.name == "nt":
            threading.Thread(target=self._watch_escape, daemon=True).start()

    def _watch_escape(self):
        import ctypes
        # Keep polling while recognition/UCI is busy, so a brief Esc press
        # between two screenshots still stops the next input action.
        while not self.event.is_set() and not self._watcher_stop.wait(.02):
            if ctypes.windll.user32.GetAsyncKeyState(0x1B) & 0x8000:
                self.event.set()

    def close(self):
        self._watcher_stop.set()

    def set(self):
        self.event.set()

    def is_set(self):
        if os.name == "nt":
            import ctypes
            if ctypes.windll.user32.GetAsyncKeyState(0x1B) & 0x8000:
                self.event.set()
        return self.event.is_set()

    def check(self):
        if self.is_set():
            raise InterruptedError("已停止；若棋子仍抬高，请先手动取消选择")

    def wait(self, seconds):
        import time
        end = time.monotonic()+seconds
        while time.monotonic() < end:
            self.check()
            self.event.wait(min(.04, max(0, end-time.monotonic())))
        self.check()


class Desktop:
    name = "电脑投屏"

    def full(self):
        if os.name == "nt":
            import ctypes
            u = ctypes.windll.user32
            left, top = u.GetSystemMetrics(76), u.GetSystemMetrics(77)
        else:
            left = top = 0
        return ImageGrab.grab(all_screens=True).convert("RGB"), (left, top)

    def frame(self, grid: Grid):
        box = grid.bbox()
        if os.name == "nt":
            import ctypes
            u = ctypes.windll.user32
            x, y, w, h = (u.GetSystemMetrics(i) for i in (76, 77, 78, 79))
            if box[0] < x or box[1] < y or box[2] > x+w or box[3] > y+h:
                raise RuntimeError("棋盘区域已超出屏幕，请重新校准")
        return ImageGrab.grab(bbox=box, all_screens=True).convert("RGB"), grid.local(box[:2])

    def tap(self, point, token: StopToken):
        token.check()
        x, y = map(round, point)
        if os.name == "nt":
            import ctypes
            u = ctypes.windll.user32
            if not u.SetCursorPos(x, y):
                raise RuntimeError("无法移动鼠标；请检查投屏软件的权限")
            u.mouse_event(0x0002, 0, 0, 0, 0)
            try:
                token.wait(.05)
            finally:
                u.mouse_event(0x0004, 0, 0, 0, 0)
        else:
            try:
                import pyautogui
            except ImportError as exc:
                raise RuntimeError("非 Windows 鼠标模式需要安装 pyautogui") from exc
            pyautogui.click(x, y)


class Android:
    name = "Android ADB"

    def __init__(self, executable="adb", serial=""):
        self.executable, self.serial = executable or "adb", serial.strip()

    def _run(self, *args, timeout=8):
        command = [self.executable]+(["-s", self.serial] if self.serial else [])+list(args)
        try:
            result = subprocess.run(command, capture_output=True, timeout=timeout,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        except FileNotFoundError as exc:
            raise RuntimeError("找不到 adb；请安装 Android platform-tools 并选择 adb.exe") from exc
        if result.returncode:
            raise RuntimeError("ADB: "+result.stderr.decode("utf-8", "replace")[:500])
        return result.stdout

    def full(self):
        data = self._run("exec-out", "screencap", "-p")
        return Image.open(BytesIO(data)).convert("RGB"), (0, 0)

    def frame(self, grid: Grid):
        image, _ = self.full()
        box = grid.bbox()
        if box[0] < 0 or box[1] < 0 or box[2] > image.width or box[3] > image.height:
            raise RuntimeError("手机尺寸已变化，请重新校准")
        return image.crop(box), grid.local(box[:2])

    def tap(self, point, token: StopToken):
        token.check()
        self._run("shell", "input", "tap", str(round(point[0])), str(round(point[1])), timeout=4)
