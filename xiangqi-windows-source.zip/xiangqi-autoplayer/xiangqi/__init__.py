"""Screen-based Xiangqi assistant powered by an external Pikafish engine."""
