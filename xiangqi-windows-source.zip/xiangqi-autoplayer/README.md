# 皮卡鱼投屏自动象棋

针对你提供的这套棋盘皮肤制作的桌面程序。它读取屏幕上的象棋棋盘，通过皮卡鱼（Pikafish）计算走法，再依次点击棋子与落点。中文界面可校准区域、预览识别结果、选择执红或执黑、只计算一步、持续自动下棋和停止。

## 免安装 Python 的 Windows 便携包

现已增加 GitHub Actions Windows 64 位 EXE 构建。下载 `XiangqiAutoPlayer-Windows-x64.zip` 后完整解压，打开其中的 `XiangqiAutoPlayer` 文件夹，双击 `XiangqiAutoPlayer.exe`。必须保留 `_internal` 和 `engine` 等整个文件夹。构建产物内置 Python 运行环境、棋子模板、官方 Windows x64 皮卡鱼及匹配 NNUE，不需要单独安装 Python 或下载引擎。

构建记录：https://github.com/Mary253j/suisui-reminder/actions/workflows/xiangqi-windows-build.yml

下面的 Python 安装步骤仅适用于源码包。

## Windows 使用步骤

1. 解压整个文件夹到普通用户可写目录，例如 `D:\XiangqiAutoPlayer`。
2. 安装 **Python 3.11 或 3.12 的 Windows 64 位版本**，勾选 **Add python.exe to PATH**。下载地址：<https://www.python.org/downloads/windows/>。程序兼容 Python 3.10 及以上。
3. 双击 **`download_engine.bat`**，下载官方皮卡鱼并校验 SHA-256。首次运行会安装程序依赖。若网络无法访问 GitHub，可从[官方发布页](https://github.com/official-pikafish/Pikafish/releases/tag/Pikafish-2026-09-06)手动下载，使用 7-Zip 解压至 `engine` 文件夹。
4. 双击 **`start.bat`** 打开程序。选择与你的电脑系统匹配的皮卡鱼可执行文件。Windows 电脑选择发布包中 Windows 对应的 `.exe`；2026-09-06 版本使用通用二进制，可自动选择 CPU 指令集。保留随包提供的 NNUE 文件及目录结构。
5. 打开手机投屏，让完整棋盘保持可见。先在投屏里手动试一下能否用鼠标选子、落子。能操作就选 **电脑投屏（鼠标）**。
6. 选择 **红方在下／红方在上**，然后点击 **校准棋盘**。程序隐藏三秒后截取桌面，显示截图供你标点。先点**左上角交叉点**，再点**右下角交叉点**。开局时它们分别是左上车、右下车所在的棋盘线交点，**不要点棋盘外框**。
7. 设置 **程序执棋** 和 **当前轮到**。初始局面是红方先走；中途接局请明确当前谁走。静态棋盘无法可靠判断行棋方，因此需要你设置。
8. 点击 **识别预览**，在 **识别棋盘（请核对）** 页逐子核对。确认没有棋子被选中、局面识别正确后，先点 **只计算一步** 检查引擎，再重新预览，点击 **自动开始**。
9. Windows 下按 **Esc** 可全局停止，也可点击 **停止**。停止后若棋子仍然抬高，请手动取消选择，再重新预览。

运行期间保持投屏窗口位置、尺寸和手机方向不变，让棋盘始终可见，并保持电脑唤醒。移动窗口、缩放投屏、切换设备、切换棋盘方向或开始新局后，应停止并重新校准／预览。程序窗口也不能覆盖投屏棋盘。初次使用建议在练习局试运行。

## 投屏只能显示，不能用鼠标操作

这不能仅凭截图判断。程序提供 **Android ADB（直连）** 模式：通过 USB 获取手机截图并发送两次触屏点击，识别和走棋逻辑相同，不需要把电脑坐标映射为手机坐标。

1. 安装 Google 官方 [Android SDK Platform-Tools](https://developer.android.com/tools/releases/platform-tools)。
2. 手机开启开发者选项与 USB 调试，用数据线连接电脑，并在手机上允许该电脑调试。部分厂商还要求开启允许 USB 模拟输入的选项。
3. 在程序里切换到 **Android ADB（直连）**，选择 `adb.exe`。连接多个 Android 设备时，填写 `adb devices` 显示的目标设备序列号。
4. **重新校准**。这时校准截图来自手机本身，标出手机截图里的两个交叉点，再预览并开始。

ADB 模式只适用于允许调试与输入的 Android 设备。iPhone 或禁用调试的手机，需要投屏软件自身支持鼠标控制。

## 已实现的识别与执行保护

- 使用样图中棋子的字形模板识别 14 类红黑棋子，不依赖通用中文 OCR，不需要在线识别服务。
- 识别前过滤绿色标记；字形中心匹配忽略外围白圈，并搜索竖直偏移以识别抬高的棋子。
- 检测到抬高的棋子时不允许开始，避免“第一次点击反而取消选中”。自动选子后，必须核对计划棋子确实被选中抬高，才会点击落点。
- 棋盘需连续两次识别一致，才进入下一阶段。引擎计算结束后再次核对局面，防止根据过期截图点击。
- 包含完整的基础象棋走法校验：马腿、象眼、炮架、九宫、过河兵、将帅照面和自陷被将。
- 通过 UCI 向皮卡鱼提供起始 FEN 和本次会话完整走棋历史。复杂重复局面规则由皮卡鱼处理；中途接局之前的历史无法从截图恢复。
- 点击棋子，再点击落点，然后重新识别核对结果。也能识别对方在核对期间迅速回棋的情况。
- 棋盘变化无法用一步合法走棋解释、置信度不足、引擎异常或点击未生效时暂停；不会因点击失败而重复落子。
- 默认思考 1500 毫秒、2 线程、128 MB Hash。思考时间不包含截图、识别、点击和核对所需时间。

## 适用范围与实际限制

当前模板专门适配你上传的棋盘皮肤。支持缩放与棋盘红黑方向切换，但需要清晰、正对屏幕、横平竖直的棋盘；不支持透视倾斜、换皮肤或任意其他游戏棋子。校准后的格距至少 22 像素，建议每格 40 像素以上。若投屏很小、压缩模糊或出现弹窗，程序会尽量暂停，不能保证任意画面都正确识别。

轮到谁走需要你设置；白圈和绿点不用于推断行棋方。程序不会点击“再来一局”、登录或处理结算弹窗。新局、悔棋、翻转、手动干预后，应停止、核对并重新开始。

**本包为 Windows 优先的 Python 运行包，需要 Python 和独立的皮卡鱼引擎。** 本次已在 Linux 环境验证你提供的三张图片及自动化逻辑；尚未在你的真实 Windows 桌面、投屏软件或手机上完成端到端联调。交付包未内置引擎二进制。官方引擎下载脚本已固定发布版本和官方公布的校验值，本次环境未实际下载运行该引擎。

## 排查问题

| 现象 | 处理 |
| --- | --- |
| 棋子识别错误／很多不确定格 | 放大投屏；确保是同一皮肤；重新标定两个交叉点；查看识别棋盘页 |
| 识别正确但不能开始 | 取消棋子选择；确认两方将帅齐全且位置正确；检查“当前轮到” |
| 点击没有作用 | 先手动测试投屏鼠标控制；Android 可切换 ADB 模式；检查投屏软件是否以管理员权限运行 |
| 选择棋子后暂停 | 手机仍在动画中、坐标不准或棋盘被遮挡；取消选择并重新预览 |
| 引擎一启动就退出 | 检查是否选择了正确系统的程序；NNUE 是否缺失；保留官方解压结构；查看日志中的引擎报错 |
| 下载失败 | 使用官方发布页手动下载；不要把 HTML 错误页改名为 `.7z`；不一致的 SHA-256 不会通过校验 |
| 中途接局后走错方 | 停止，重新设置“当前轮到”和“程序执棋”，重新预览 |

配置保存在 `config.json`，运行日志位于 `logs/`。点击 **保存诊断截图及局面** 可保存当前棋盘截图和逐格识别分数，便于校准问题定位；文件只写入本机。

## 开发、测试和生成 EXE

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python app.py --recognize assets/samples/initial.jpg --output initial-check.png
python app.py --recognize assets/samples/selected.jpg
python app.py --recognize assets/samples/moved.jpg
```

任意图片可附带 `--grid 左上x 左上y 右下x 右下y`；`--red-top` 表示红方在上。CLI 输出的 FEN 默认标为红方行棋，不代表已从图片判断出行棋方。

下载真实引擎后可运行四步集成检查：

```bash
python tools/check_engine.py "D:\path\to\pikafish.exe"
```

测试覆盖：三个用户样图、选子抬高、绿点及白圈、缩放和 JPEG 压缩、翻转布局、初始局面合法着法数量 44/1920、UCI 通信与异常处理、双击落子核对、快速回棋、失败不重试、停止不点击和只计算模式。UCI 单元测试使用协议测试进程，真实皮卡鱼需用上述集成检查验证。

如需分发不依赖预装 Python 的 Windows 程序，在 Windows 上双击 **`build_exe.bat`**。结果位于 `dist\XiangqiAutoPlayer\XiangqiAutoPlayer.exe`，需要复制整个 `XiangqiAutoPlayer` 文件夹，并配置独立皮卡鱼引擎。本包没有预先编译的 Windows EXE。

Linux/macOS 可用 `python app.py` 启动，鼠标控制另需安装 `pyautogui`；截图、辅助功能权限与全局停止行为依赖系统。**全局 Esc 停止仅在 Windows 原生实现**，其他系统可使用界面停止按钮。本次未验证非 Windows 的实际桌面控制。

## 文件结构

```text
app.py                  桌面界面和离线图片识别入口
start.bat               Windows 启动与依赖安装
download_engine.bat     官方皮卡鱼下载入口
build_exe.bat           在 Windows 上生成 EXE
xiangqi/vision.py       棋盘坐标、字形模板和置信度
xiangqi/model.py        FEN、合法走棋与局面变化校验
xiangqi/engine.py       皮卡鱼 UCI 进程通信
xiangqi/device.py       截屏、鼠标、ADB 与停止信号
xiangqi/runner.py       稳定画面、计算、选子、落点、回读状态流程
xiangqi/gui.py          中文操作界面
assets/templates.npz    根据用户样图生成的棋子模板
assets/samples/         三张原始参考图片
tests/                  离线测试
tools/                  下载工具与真实引擎检查工具
```
