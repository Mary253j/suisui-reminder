"""Package only source and glyph templates for the approved isolated build branch."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json
root=Path(__file__).resolve().parents[1]
output=root.parent/'xiangqi-windows-cloud-ready.zip'
with ZipFile(output,'w',ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if not p.is_file() or any(k in {'.venv','__pycache__','build','dist','engine','windows-cache','logs','samples','.git'} for k in rel.parts):continue
        if p.name in {'config.json','BUILD_RESULT.json'} or p.suffix.lower() in {'.jpg','.jpeg','.png','.exe','.zip','.7z','.pyc'}:continue
        z.write(p,Path(root.name)/rel)
with ZipFile(output) as z:
    assert z.testzip() is None
    assert 'xiangqi-autoplayer/assets/templates.npz' in z.namelist()
    assert not any('/samples/' in n or n.lower().endswith(('.jpg','.png','.jpeg')) for n in z.namelist())
print(json.dumps({'bytes':output.stat().st_size,'base64_length':4*((output.stat().st_size+2)//3),'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}))
