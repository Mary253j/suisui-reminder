"""Prepare an offline Windows distribution with the verified official engine."""
from pathlib import Path
import hashlib
import shutil
import tarfile
import sys
import importlib.metadata
from urllib.request import urlopen
from download_pikafish import download, verify, extract, VERSION

ROOT = Path(__file__).resolve().parents[1]

def main():
    cache=ROOT/'windows-cache';cache.mkdir(exist_ok=True)
    archive=cache/f'Pikafish.{VERSION}.7z'
    if not archive.exists():download(archive)
    verify(archive)
    extract(archive,cache/'unpacked')
    files=[p for p in (cache/'unpacked').rglob('*') if p.is_file()]
    binaries=[p for p in files if 'windows' in p.name.lower() and 'arm' not in p.name.lower()
              and ('x86-64' in p.name.lower() or 'x86_64' in p.name.lower()) and p.suffix.lower()=='.exe']
    baseline=[p for p in binaries if 'universal' in p.name.lower()]
    if baseline:binaries=baseline
    if len(binaries)!=1:raise RuntimeError('Windows x64 engine selection ambiguous: '+str(binaries))
    networks=[p for p in files if p.suffix.lower()=='.nnue']
    if len(networks)!=1:raise RuntimeError('NNUE selection ambiguous')
    destination=ROOT/'dist/XiangqiAutoPlayer/engine';destination.mkdir(parents=True,exist_ok=True)
    binary=binaries[0];data=binary.read_bytes()
    if data[:2]!=b'MZ':raise RuntimeError('Not a Windows executable')
    pe=int.from_bytes(data[60:64],'little')
    if data[pe:pe+4]!=b'PE\0\0' or int.from_bytes(data[pe+4:pe+6],'little')!=0x8664:
        raise RuntimeError('Not Windows x64 PE')
    shutil.copyfile(binary,destination/'pikafish.exe')
    shutil.copyfile(networks[0],destination/'pikafish.nnue')
    for name in ('NNUE-License.md','AUTHORS','Copying.txt'):
        for p in files:
            if p.name==name:shutil.copyfile(p,destination/name)
    source_url=f'https://github.com/official-pikafish/Pikafish/archive/refs/tags/Pikafish-{VERSION}.tar.gz'
    source=destination/'pikafish-source.tar.gz'
    with urlopen(source_url,timeout=30) as r,source.open('wb') as f:shutil.copyfileobj(r,f)
    with tarfile.open(source,'r:gz') as tar:
        license=min((m for m in tar.getmembers() if m.isfile() and Path(m.name).name.lower() in ('copying','copying.txt','license','license.txt')),key=lambda m:len(m.name))
        (destination/'COPYING.txt').write_bytes(tar.extractfile(license).read())
    (destination/'SOURCE.txt').write_text(f'Official Pikafish {VERSION}\n{source_url}\nCorresponding unmodified source is bundled in pikafish-source.tar.gz\n','utf-8')
    (destination/'SHA256.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name for p in destination.iterdir() if p.is_file())+'\n','utf-8')
    shutil.copyfile(ROOT/'WINDOWS_QUICK_START.txt',destination.parent/'开始使用.txt')
    shutil.copyfile(ROOT/'THIRD_PARTY.md',destination.parent/'THIRD_PARTY.md')
    licenses=destination.parent/'licenses';licenses.mkdir(exist_ok=True)
    for name in ('numpy','Pillow','PyInstaller'):
        distribution=importlib.metadata.distribution(name)
        for relative in distribution.files or []:
            if 'license' in relative.name.lower() or relative.name.lower()=='copying':
                source=distribution.locate_file(relative)
                if source.is_file():shutil.copyfile(source,licenses/(name+'-'+relative.name))
    for p in [Path(sys.base_prefix)/'LICENSE.txt',*(Path(sys.base_prefix)/'tcl').rglob('license.terms')]:
        if p.is_file():shutil.copyfile(p,licenses/(p.parent.name+'-'+p.name))
    print('Packaged official Windows x64 engine:',binary.name)
    print(destination/'pikafish.exe')

if __name__=='__main__':main()
