"""Real-engine integration check, run after installing official Pikafish."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from xiangqi.engine import Pikafish
from xiangqi.model import Position, START_FEN, Move

parser = argparse.ArgumentParser()
parser.add_argument("engine", type=Path)
args = parser.parse_args()
with Pikafish(args.engine, threads=2, hash_mb=64) as engine:
    position = Position.from_fen(START_FEN)
    history = []
    print("Engine:", engine.name)
    for ply in range(4):
        text = engine.bestmove(START_FEN, history, 200)
        move = Move.parse(text)
        if move not in position.legal_moves():
            raise RuntimeError("Illegal engine move: "+text)
        position = position.apply(move)
        history.append(text)
        print(ply+1, text, position.fen())
    print("PASS: handshake, NNUE loading, legal moves and UCI history.")
