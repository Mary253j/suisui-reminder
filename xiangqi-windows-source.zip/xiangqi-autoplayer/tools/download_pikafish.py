"""Download a pinned official release and verify its published SHA-256."""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import time
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
VERSION = "2026-09-06"
URL = "https://github.com/official-pikafish/Pikafish/releases/download/Pikafish-2026-09-06/Pikafish.2026-09-06.7z"
SHA256 = "41952bbfe2520faceb5902c69e6ab4845cc999841d2b49a95cc1be7867a25e5b"


def download(target):
    partial = target.with_suffix(".7z.download")
    print("Downloading official Pikafish:", URL, flush=True)
    request = Request(URL, headers={"User-Agent": "Xiangqi-Screen-Assistant/1.0"})
    try:
        with urlopen(request, timeout=30) as response, partial.open("wb") as output:
            total = int(response.headers.get("Content-Length", 0))
            got, last = 0, 0
            while True:
                block = response.read(1024*512)
                if not block:
                    break
                got += len(block)
                if got > 150*1024*1024:
                    raise RuntimeError("Release exceeded expected download size")
                output.write(block)
                if time.monotonic()-last > 2:
                    print(f"  {got/1024/1024:.1f} MB / {total/1024/1024:.1f} MB", flush=True)
                    last = time.monotonic()
        partial.replace(target)
    finally:
        partial.unlink(missing_ok=True)


def verify(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""):
            digest.update(block)
    if digest.hexdigest() != SHA256:
        raise RuntimeError("SHA-256 mismatch. Do not run this archive; delete it and download again.")
    print("Official SHA-256 verified.", flush=True)


def extract(path, destination):
    seven = shutil.which("7z") or shutil.which("7za")
    if seven:
        subprocess.run([seven, "x", str(path), "-o"+str(destination), "-y"], check=True)
        return
    try:
        import py7zr
    except ImportError as exc:
        raise RuntimeError("Install py7zr (python -m pip install py7zr), or extract the verified archive manually with 7-Zip.") from exc
    with py7zr.SevenZipFile(path, mode="r") as archive:
        for name in archive.getnames():
            p = PurePosixPath(name.replace("\\", "/"))
            if p.is_absolute() or ".." in p.parts or ":" in name:
                raise RuntimeError("Unsafe archive member: "+name)
        archive.extractall(destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, help="Use a locally downloaded official archive")
    parser.add_argument("--destination", type=Path, default=ROOT/"engine")
    args = parser.parse_args()
    destination = args.destination.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    archive = args.archive.resolve() if args.archive else destination/f"Pikafish.{VERSION}.7z"
    if not archive.exists():
        if args.archive:
            raise FileNotFoundError(archive)
        download(archive)
    verify(archive)
    extract(archive, destination)
    executables = [p for p in destination.rglob("*") if p.is_file() and "pikafish" in p.name.lower() and (p.suffix.lower()==".exe" or "linux" in p.name.lower() or "macos" in p.name.lower())]
    print("\nExtracted to:", destination)
    for p in executables[:20]:
        print(" ", p.relative_to(destination))
    print("\nOpen start.bat and select the executable matching your operating system.")
    print("Keep any accompanying NNUE file in its original folder.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("\nFAILED:", exc, file=sys.stderr)
        print("Manual official download: "+URL, file=sys.stderr)
        sys.exit(1)
