@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
call setup.bat
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -c "import py7zr" >nul 2>nul
if not errorlevel 1 goto download
".venv\Scripts\python.exe" -m pip install --timeout 20 --retries 1 "py7zr>=1.0,<2"
if errorlevel 1 goto fail
:download
".venv\Scripts\python.exe" tools\download_pikafish.py
if errorlevel 1 goto fail
echo.
echo Done. You can now run start.bat.
pause
exit /b 0
:fail
echo.
echo Download failed. You can download and extract Pikafish manually. See README.md.
pause
exit /b 1
